#ifndef __HTTP_CLIENT_H__
#define __HTTP_CLIENT_H__

#include <certh_core/Dictionary.h>

#include <iostream>
#include <map>

#include <boost/filesystem.hpp>

namespace certh_aux { namespace Http {

// High-level http client wrapper over cURL library

class Client
{
    public:

    Client(const std::string &requestUrl) ;
    ~Client() ;

    bool setUser(const std::string &userName, const std::string &password) ;
    bool setPort(int port) ;

    // set additional headers for this request
    void setHeaders(const std::string &key, const std::string &value) ;

    // if verifyPeer is true SSL will try to verify the certificate provided by the server otherwise
    // the certficate will be accepted. If verifyHost is true the request will fail in the case that
    // the certificate issuer name is other than the server name requested. These are by default true.
    bool setSSLVerifyCertificate(bool verifyPeer, bool verifyHost = false) ;

    // Set a file in PEM format to be used for validating the certificate received by the server
    bool setSSLCertificate(const boost::filesystem::path &pemFile) ;

    // GET method, write response header to internal string and body to specified strm object

    bool get(std::ostream &strm) ;

    // POST of raw data
    bool postRawData(const std::string &data, const std::string &mime, std::ostream &strm) ;

    // POST a url-encoded form where key/value pairs are given in data.
    // Also handles file upload. In that case the corresponding dictionary entry value should be specified as
    // @filename;type=mime or @filename

    bool postForm(const certh_core::Dictionary &data, std::ostream &strm);

    // POST a url encoded string e.g. key1=val1@key2=val2 ;
    bool postUrlEncodedString(const std::string &data, std::ostream &strm) ;
    bool postUrlEncodedString(const certh_core::Dictionary &data, std::ostream &strm) ;

    const std::string lastError() const { return error_buf_ ; }

private:

  friend class HeadersWriter ;

  void *handle_ ;

  char error_buf_[512] ;

  std::string response_header_ ;
  certh_core::Dictionary headers_ ;

} ;

// Download data from uri and write to a stream with optional caching

bool download(const std::string &uri, std::ostream &strm, const boost::filesystem::path &cacheDir = boost::filesystem::path()) ;

} // namespace Http
} // namespace aux











#endif
