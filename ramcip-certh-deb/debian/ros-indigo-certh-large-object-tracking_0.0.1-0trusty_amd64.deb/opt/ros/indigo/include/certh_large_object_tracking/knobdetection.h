#ifndef KNOBDETECTION_H
#define KNOBDETECTION_H

#include <pcl/common/centroid.h>
#include <pcl/conversions.h>
#include <pcl/common/transforms.h>
#include <pcl/common/common.h>
#include <vector>
#include <pcl/io/pcd_io.h>
#include <pcl/point_types.h>
#include <boost/thread/thread.hpp>
#include <opencv2/opencv.hpp>

#include <dlib/svm_threaded.h>
#include <dlib/gui_widgets.h>
#include <dlib/image_processing.h>
#include <dlib/data_io.h>
#include <dlib/svm_threaded.h>
#include <dlib/gui_widgets.h>
#include <dlib/image_processing.h>
#include <dlib/data_io.h>
#include <dlib/opencv/cv_image.h>
#include <dlib/opencv.h>

#include <dlib/opencv/to_open_cv.h>

#include <boost/lexical_cast.hpp>
#include <iostream>
#include <fstream>

#include <sensor_msgs/CameraInfo.h>

struct Intrinsics_ {
    float fx ;
    float fy ;
    float cx ;
    float cy ;
};

struct knob {
    float x;
    float y;
    float z;
    std::string state;
    int offset;
};

struct PairCompare {
  bool operator() (const std::pair<float, int>& firstElem, const std::pair<float, int>& secondElem) {
    return firstElem.first > secondElem.first;
  }
};

class knobDetection
{
public:
  knobDetection();
  knobDetection(cv::Mat &rgb,cv::Mat &depth,sensor_msgs::CameraInfo cam, std::string model_path);
  std::vector<std::string> detect_knobs_state_monitoring ();
  std::vector<knob> detect_knobs_state_manipulation();
  std::vector<std::pair<cv::Rect, cv::Point2i> > detected_knobs_;
private:
  pcl::PointCloud<pcl::PointXYZ> extract_bb();
  cv::Rect extract_roi(pcl::PointCloud<pcl::PointXYZ> &cloudbb);
  cv::Point2f project(const cv::Point3f& xyz, float fx_, float fy_, float cx_, float cy_);
  std::vector<cv::Mat> detect_knobs_monitoring (cv::Mat &in);
  std::vector<cv::Mat> detect_knobs_manipulation (cv::Mat &in);
  std::vector<std::string> detect_states_monitoring(std::vector<cv::Mat> &knobs);
  std::vector<std::pair<std::string, int> > detect_states_manipulation(std::vector<cv::Mat> &knobs);
  cv::Mat extractHogFeatVector(cv::Mat &img);
//  Eigen::Affine3f camera_pose_ ;
  Intrinsics_ cam_model_ ;
  cv::Mat rgb_;
  cv::Mat depth_;
  std::string model_path_;

};

class CvRTreesMultiClass : public CvRTrees
{
public:
  int predict_multi_class(const cv::Mat &sample, std::vector<float>& out_votes,
                          const cv::Mat &missing = cv::Mat()) const;
};





#endif // KNOBDETECTION_H
