#ifndef CONSTRAINEDSVD_H
#define CONSTRAINEDSVD_H

#include <pcl/registration/transformation_estimation.h>
#include <pcl/cloud_iterator.h>

template <typename PointSource, typename PointTarget, typename Scalar = float>
    class ConstrSVD : public pcl::registration::TransformationEstimation<PointSource, PointTarget, Scalar>
    {
      public:
        typedef boost::shared_ptr<ConstrSVD<PointSource, PointTarget, Scalar> > Ptr;
        typedef boost::shared_ptr<const ConstrSVD<PointSource, PointTarget, Scalar> > ConstPtr;

        typedef typename pcl::registration::TransformationEstimation<PointSource, PointTarget, Scalar>::Matrix4 Matrix4;

        /** \brief Constructor
          * \param[in] use_umeyama Toggles whether or not to use 3rd party software*/
//        ConstrSVD (){}

        ConstrSVD (std::string joint_type = "revolute", std::string transf_axis = "z", double min = 0.0, double max = 0.0): joint_type_(joint_type), transf_axis_(transf_axis), min_(min), max_(max) {}
        virtual ~ConstrSVD () {};

        /** \brief Estimate a rigid rotation transformation between a source and a target point cloud using SVD.
          * \param[in] cloud_src the source point cloud dataset
          * \param[in] cloud_tgt the target point cloud dataset
          * \param[out] transformation_matrix the resultant transformation matrix
          */
        void
        estimateRigidTransformation (
            const pcl::PointCloud<PointSource> &cloud_src,
            const pcl::PointCloud<PointTarget> &cloud_tgt,
            Matrix4 &transformation_matrix) const;

        /** \brief Estimate a rigid rotation transformation between a source and a target point cloud using SVD.
          * \param[in] cloud_src the source point cloud dataset
          * \param[in] indices_src the vector of indices describing the points of interest in \a cloud_src
          * \param[in] cloud_tgt the target point cloud dataset
          * \param[out] transformation_matrix the resultant transformation matrix
          */
        void
        estimateRigidTransformation (
            const pcl::PointCloud<PointSource> &cloud_src,
            const std::vector<int> &indices_src,
            const pcl::PointCloud<PointTarget> &cloud_tgt,
            Matrix4 &transformation_matrix) const;

        /** \brief Estimate a rigid rotation transformation between a source and a target point cloud using SVD.
          * \param[in] cloud_src the source point cloud dataset
          * \param[in] indices_src the vector of indices describing the points of interest in \a cloud_src
          * \param[in] cloud_tgt the target point cloud dataset
          * \param[in] indices_tgt the vector of indices describing the correspondences of the interst points from \a indices_src
          * \param[out] transformation_matrix the resultant transformation matrix
          */
        void
        estimateRigidTransformation (
            const pcl::PointCloud<PointSource> &cloud_src,
            const std::vector<int> &indices_src,
            const pcl::PointCloud<PointTarget> &cloud_tgt,
            const std::vector<int> &indices_tgt,
            Matrix4 &transformation_matrix) const;

        /** \brief Estimate a rigid rotation transformation between a source and a target point cloud using SVD.
          * \param[in] cloud_src the source point cloud dataset
          * \param[in] cloud_tgt the target point cloud dataset
          * \param[in] correspondences the vector of correspondences between source and target point cloud
          * \param[out] transformation_matrix the resultant transformation matrix
          */
        void
        estimateRigidTransformation (
            const pcl::PointCloud<PointSource> &cloud_src,
            const pcl::PointCloud<PointTarget> &cloud_tgt,
            const pcl::Correspondences &correspondences,
            Matrix4 &transformation_matrix) const;

      protected:

        /** \brief Estimate a rigid rotation transformation between a source and a target
          * \param[in] source_it an iterator over the source point cloud dataset
          * \param[in] target_it an iterator over the target point cloud dataset
          * \param[out] transformation_matrix the resultant transformation matrix
          */
        void
        estimateRigidTransformation (pcl::ConstCloudIterator<PointSource>& source_it,
                                     pcl::ConstCloudIterator<PointTarget>& target_it,
                                     Matrix4 &transformation_matrix) const;

        /** \brief Obtain a 4x4 rigid transformation matrix from a correlation matrix H = src * tgt'
          * \param[in] cloud_src_demean the input source cloud, demeaned, in Eigen format
          * \param[in] centroid_src the input source centroid, in Eigen format
          * \param[in] cloud_tgt_demean the input target cloud, demeaned, in Eigen format
          * \param[in] centroid_tgt the input target cloud, in Eigen format
          * \param[out] transformation_matrix the resultant 4x4 rigid transformation matrix
          */
        void
        getTransformationFromCorrelation (
            const Eigen::Matrix<Scalar, Eigen::Dynamic, Eigen::Dynamic> &cloud_src_demean,
            const Eigen::Matrix<Scalar, 4, 1> &centroid_src,
            const Eigen::Matrix<Scalar, Eigen::Dynamic, Eigen::Dynamic> &cloud_tgt_demean,
            const Eigen::Matrix<Scalar, 4, 1> &centroid_tgt,
            Matrix4 &transformation_matrix) const;

        std::string joint_type_ ;
        std::string transf_axis_ ;
        double min_, max_ ;

     };
#include "constrainedsvd.hpp"

#endif // CONSTRAINEDSVD_H
