#ifndef CONSTRAINEDP2PLLS_H 
#define CONSTRAINEDP2PLLS_H

#include <pcl/registration/transformation_estimation.h>
#include <pcl/registration/warp_point_rigid.h>
#include <pcl/cloud_iterator.h>

    /** \brief @b constrainedp2plls implements a Linear Least Squares (LLS) approximation
      * for minimizing the point-to-plane distance between two clouds of corresponding points with normals.
      *
      * For additional details, see 
      *   "Linear Least-Squares Optimization for Point-to-Plane ICP Surface Registration", Kok-Lim Low, 2004
      *
      * \note The class is templated on the source and target point types as well as on the output scalar of the
      * transformation matrix (i.e., float or double). Default: float.
      * \author Michael Dixon
      * \ingroup registration
      */
    template <typename PointSource, typename PointTarget, typename Scalar = float>
    class constrainedp2plls : public pcl::registration::TransformationEstimation<PointSource, PointTarget, Scalar>
    {
      public:
        typedef boost::shared_ptr<constrainedp2plls<PointSource, PointTarget, Scalar> > Ptr;
        typedef boost::shared_ptr<const constrainedp2plls<PointSource, PointTarget, Scalar> > ConstPtr;

        typedef typename pcl::registration::TransformationEstimation<PointSource, PointTarget, Scalar>::Matrix4 Matrix4;
        
//        constrainedp2plls () {};

        /** \brief Constructor
          * \param[in] use_umeyama Toggles whether or not to use 3rd party software*/
//        ConstrSVD (){}

        constrainedp2plls (std::string joint_type = "revolute", std::string transf_axis = "z", double min = 0.0, double max = 0.0): joint_type_(joint_type), transf_axis_(transf_axis), min_(min), max_(max) {}
        
        virtual ~constrainedp2plls () {};

        /** \brief Estimate a rigid rotation transformation between a source and a target point cloud using SVD.
          * \param[in] cloud_src the source point cloud dataset
          * \param[in] cloud_tgt the target point cloud dataset
          * \param[out] transformation_matrix the resultant transformation matrix
          */
        inline void
        estimateRigidTransformation (
            const pcl::PointCloud<PointSource> &cloud_src,
            const pcl::PointCloud<PointTarget> &cloud_tgt,
            Matrix4 &transformation_matrix) const;

        /** \brief Estimate a rigid rotation transformation between a source and a target point cloud using SVD.
          * \param[in] cloud_src the source point cloud dataset
          * \param[in] indices_src the vector of indices describing the points of interest in \a cloud_src
          * \param[in] cloud_tgt the target point cloud dataset
          * \param[out] transformation_matrix the resultant transformation matrix
          */
        inline void
        estimateRigidTransformation (
            const pcl::PointCloud<PointSource> &cloud_src,
            const std::vector<int> &indices_src,
            const pcl::PointCloud<PointTarget> &cloud_tgt,
            Matrix4 &transformation_matrix) const;

        /** \brief Estimate a rigid rotation transformation between a source and a target point cloud using SVD.
          * \param[in] cloud_src the source point cloud dataset
          * \param[in] indices_src the vector of indices describing the points of interest in \a cloud_src
          * \param[in] cloud_tgt the target point cloud dataset
          * \param[in] indices_tgt the vector of indices describing the correspondences of the interst points from \a indices_src
          * \param[out] transformation_matrix the resultant transformation matrix
          */
        inline void
        estimateRigidTransformation (
            const pcl::PointCloud<PointSource> &cloud_src,
            const std::vector<int> &indices_src,
            const pcl::PointCloud<PointTarget> &cloud_tgt,
            const std::vector<int> &indices_tgt,
            Matrix4 &transformation_matrix) const;

        /** \brief Estimate a rigid rotation transformation between a source and a target point cloud using SVD.
          * \param[in] cloud_src the source point cloud dataset
          * \param[in] cloud_tgt the target point cloud dataset
          * \param[in] correspondences the vector of correspondences between source and target point cloud
          * \param[out] transformation_matrix the resultant transformation matrix
          */
        inline void
        estimateRigidTransformation (
            const pcl::PointCloud<PointSource> &cloud_src,
            const pcl::PointCloud<PointTarget> &cloud_tgt,
            const pcl::Correspondences &correspondences,
            Matrix4 &transformation_matrix) const;

      protected:
        
        /** \brief Estimate a rigid rotation transformation between a source and a target
          * \param[in] source_it an iterator over the source point cloud dataset
          * \param[in] target_it an iterator over the target point cloud dataset
          * \param[out] transformation_matrix the resultant transformation matrix
          */
        void 
        estimateRigidTransformation (pcl::ConstCloudIterator<PointSource>& source_it,
                                     pcl::ConstCloudIterator<PointTarget>& target_it,
                                     Matrix4 &transformation_matrix) const;

        /** \brief Construct a 4 by 4 tranformation matrix from the provided rotation and translation.
          * \param[in] alpha the rotation about the x-axis
          * \param[in] beta the rotation about the y-axis
          * \param[in] gamma the rotation about the z-axis
          * \param[in] tx the x translation
          * \param[in] ty the y translation
          * \param[in] tz the z translation
          * \param[out] transformation the resultant transformation matrix
          */
        inline void
        constructTransformationMatrix (const double & alpha, const double & beta, const double & gamma,
                                       const double & tx,    const double & ty,   const double & tz,
                                       Matrix4 &transformation_matrix) const;

	std::string joint_type_ ;
        std::string transf_axis_ ;
        double min_, max_ ;

    };

#include "constrainedp2plls.hpp"

#endif 

