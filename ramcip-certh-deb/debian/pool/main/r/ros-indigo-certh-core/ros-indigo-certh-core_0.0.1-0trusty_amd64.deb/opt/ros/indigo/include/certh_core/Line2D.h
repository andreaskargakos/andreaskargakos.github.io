#ifndef _LINE2D_H_
#define _LINE2D_H_

#include <certh_core/config.h>
#include <certh_core/Point2D.h>

#include <vector>

namespace certh_core {

// 2D line 

class Line2d
{
public:

    friend class LineSegment2d ;
    // Constructors

    // Line passing from a point p with direction dir
    Line2d(const Point2d &p, const Vector2d &dir) ;

    // Line in the form a x + b * y + c = 0 ;
    Line2d(double a, double b, double c) ;

    // Line in the form a[0] * x + a[1] * y + a[2] = 0 ;

    Line2d(double a[3]) ;

    // 2D line regression. if robust = true applies robust fitting algorithm

    Line2d(const std::vector<Point2d> &pts, bool robust = false ) ;

    // Get line direction vector

    Vector2d getDir() const { return d ; }

    void getCoefs(double &a, double &b, double &c) const ;
    void getCoefs(double a[3]) const ;

    // Find the intersection between  two lines

    bool intersection(const Line2d &other, Point2d &p) const ;

    bool isParallel(const Line2d &other) const ;

    // Find the distance of a point to the line. Optionally returns the closest point on the line
    double distanceToPoint(const Point2d &p, Point2d *psd = NULL) const ;

    Point2d p ;
    Vector2d d ;

private:

    void init(double, double, double) ;
} ;

// 2D line segment

class LineSegment2d
{
public:

    // Constructors

    // Line segment defined from  two points
    LineSegment2d(const Point2d &p1, const Point2d &p2) ;


    // Line regression. End points are determined by projecting all points on the
    // the line

    LineSegment2d(const std::vector<Point2d> &pts, bool robust = true ) ;

    Line2d getLine() const ;

    // Get line direction vector

    Vector2d getDir() const ;

    // Swap end-points

    void invert() ;

    // Find the intersection between the segment and a line

    bool intersection(const Line2d &other, Point2d &p) const ;

    // Find the intersection (if any) with a line segment

    bool intersection(const LineSegment2d &other, Point2d &p) const ;

    bool isParallel(const Line2d &other) const ;
    bool isParallel(const LineSegment2d &other) const  ;

    bool isColinear(const Line2d &other) const ;
    bool isColinear(const LineSegment2d &other) const ;

    // Find the distance of a point to the line.
    // Optionally returns the closest point on the line

    double distanceToPoint(const Point2d &p, Point2d *psd = NULL) const ;

    // For points that lye on the line the function returns a flag indicating
    // whether the point is inside the line segment (0), before the first end-point
    // (-1) and after the second end-point (1)

    int contains(const Point2d &p) const ;

    Point2d pa, pb ;
} ;

}

#endif
