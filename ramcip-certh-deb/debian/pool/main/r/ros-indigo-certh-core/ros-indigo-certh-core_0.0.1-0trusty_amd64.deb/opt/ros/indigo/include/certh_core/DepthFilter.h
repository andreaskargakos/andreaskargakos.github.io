/*Depth map refinment filter
 *-for averaging multiple depth images,choose filtertype=0
 *-for bilateral filtering with opencv function bilateralFilter(), choose  filtertype=1
 *-for bilateral filtering with bilateralFilter() function (not from opencv) choose filtertype=2
 *-for multilateral filtering with trilateralFilter() function choose filtertype=3
 *-for multilateral filtering with weighttrilateralFilter() function choose filtertype=4
 *-for filtering with weightedjointbilateralfilter() function (slow implementation) choose filtertype=5
 *-filtering with weightedjointbilateralfilter() function (fast implementation)  choose filtertype=6 */

#ifndef _DEPTH_FILTER_H_
#define _DEPTH_FILTER_H_

#include <certh_core/config.h>

#include <opencv2/opencv.hpp>
#include <opencv2/core/core.hpp>
#include <opencv2/imgproc/imgproc.hpp>


enum {
    DEPTH_FILTER_AVERAGE = 0,
    DEPTH_FILTER_BILATERAL_OPENCV = 1,
    DEPTH_FILTER_MULTILATERAL = 2,
    DEPTH_FILTER_MULTILATERAL_WEIGHTED =3,
    DEPTH_FILTER_JOINT_BILATERAL =4,
    DEPTH_FILTER_JOINT_BILATERAL_FAST = 5
} ;

namespace certh_core {


class DepthFilter
{
public:

    DepthFilter();

    void push(const cv::Mat &srcDepth, const int minZ = 0, const int maxZ = 0) ;
    void push(const cv::Mat &srcDepth, const cv::Mat &srcRgb, const int minZ = 0, const int maxZ = 0) ;
    void init() ;

    cv::Mat filter(int filtertype);

private:

    cv::Mat rgb;
    cv::Mat averagedepth;
    cv::Mat counters;
    void getrange(const cv::Mat &srcDepth);
};


} // namespace certh_core
#endif // _DEPTH_FILTER_H_
