#ifndef _CERTH_CORE_CONFIG_H_
#define _CERTH_CORE_CONFIG_H_

#ifdef _WIN32
#pragma warning (disable : 4018)
#pragma warning (disable : 4661)
#pragma warning (disable : 4275)
#pragma warning (disable : 4660)
#pragma warning (disable : 4251)
#pragma warning (disable : 4244)
#pragma warning (disable : 4800)
#pragma warning (disable : 4231)
#pragma warning (disable : 4786)

#if defined (vlcore_EXPORTS)
#define __declspec(dllexport)
#else
#define __declspec(dllimport)
#endif

#define _USE_MATH_DEFINES
#include <cmath>

#else
#define VLDLLAPI
#define _int64 long long int
#endif

#endif
