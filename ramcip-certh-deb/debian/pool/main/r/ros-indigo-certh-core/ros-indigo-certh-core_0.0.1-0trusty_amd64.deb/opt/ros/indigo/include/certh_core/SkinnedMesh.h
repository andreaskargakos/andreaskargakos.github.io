#ifndef __SKINNED_MESH_H__
#define __SKINNED_MESH_H__

#include <certh_core/Skeleton.h>
#include <certh_core/Pose.h>


namespace certh_core {
// A generic skinned mesh

class SkinnedMesh {
public:

    SkinnedMesh() {}

    // apply the given bone transformations to the mesh and return new vertices and normals.

      void getTransformedVertices(const Pose &p, std::vector<Eigen::Vector3f> &mpos, std::vector<Eigen::Vector3f> &mnorm) const;

    void getTransformedVertices(const Pose &p, std::vector<Eigen::Vector3f> &mpos, std::vector<Eigen::Vector3f> &mnorm, Eigen::Vector3f& bboxMin, Eigen::Vector3f& bboxMax) const ;

    void getTransformedVertices(const Pose &p, const std::vector<uint32_t> indices, std::vector<Eigen::Vector3f> &mpos,Eigen::Vector3f& bboxMin, Eigen::Vector3f& bboxMax) const;

    void getTransformedVertices(const Pose &p, std::vector<Eigen::Vector3f> &mpos) const ;

    void getTransformedVertices(const Pose &p, const std::vector<uint32_t> indices,
                                std::vector<Eigen::Vector3f> &mpos, std::vector<Eigen::Vector3f> &mnorm) const ;

    void getTransformedVertices(const Pose &p, const std::vector<uint32_t> indices, std::vector<Eigen::Vector3f> &mpos) const;


    void getTransformedVerticesPartial(const Pose &p, const std::vector<std::string> &bones, std::vector<Eigen::Vector3f> &mpos, std::vector<Eigen::Vector3f> &mnorm) const ;

    void makeColorMap(std::vector<cv::Vec3b> &clrs) ;

    uint getDominantBone(const uint vtx_idx) const ;

    void computeWeights() ;

public:

#define MAX_BONES_PER_VERTEX 4

    struct VertexBoneData
    {
        int id_[MAX_BONES_PER_VERTEX];
        float weight_[MAX_BONES_PER_VERTEX];

        VertexBoneData() ;

        void reset() ;
        void addBoneData(uint boneID, float w) ;
        void normalize() ;
    };

    // flat version of mesh data (e.g. to be used for rendering)

    std::vector<Eigen::Vector3f> positions_ ;
    std::vector<Eigen::Vector3f> normals_ ;
    std::vector<Eigen::Vector2f> tex_coords_ ;
    std::vector<VertexBoneData> bones_ ;
    std::vector<uint> indices_ ;
    std::vector<double> weights_ ;

    Skeleton skeleton_ ;

};

} // namespace certh_core

#endif
