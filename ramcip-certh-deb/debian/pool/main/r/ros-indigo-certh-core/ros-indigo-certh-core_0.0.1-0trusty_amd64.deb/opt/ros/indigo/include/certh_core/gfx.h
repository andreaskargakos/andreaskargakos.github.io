#ifndef _GFX_H_
#define _GFX_H_

#include <certh_core/config.h>

#include <vector>
#include <boost/shared_ptr.hpp>

#include <opencv2/opencv.hpp>

// 2D graphics API on top of cairo 2D graphics library inspired by SVG.

namespace certh_core { namespace gfx {

// generic drawing surface

class Surface
{
protected:

    Surface(double w, double h): width_(w), height_(h), handle_(0) {}
    virtual ~Surface() ;

    friend class Context ;

    void *handle_ ;
    double width_ ;
    double height_ ;
} ;

// draw on an image

class ImageSurface: public Surface
{
public:

    ImageSurface(int w, int h, int dpi=300) ;

    void saveToPng(const std::string &fname) ;

    cv::Mat getImage(bool transparency = false) const ;

private:

    int dpi_ ;

} ;

class PDFSurface: public Surface
{
public:

    PDFSurface(const std::string &fileName, double w, double h, int dpi=300) ;

private:

    int dpi_ ;
} ;

class PSSurface: public Surface
{
public:

    PSSurface(const std::string &fileName, double w, double h, int dpi=300) ;

private:

    int dpi_ ;
} ;


class PatternSurface: public Surface
{
public:

    PatternSurface(double w, double h) ;
};

#define DASH_ARRAY_LENGTH 10


struct Color {

    Color(double r, double g, double b) ;
    Color(double r, double g, double b, double a) ;

    // initialize from a CSS2 name or rgb specification
    Color(const std::string &name) ;
    Color(const std::string &name, double alpha) ;

    double r() const { return r_ ; }
    double g() const { return g_ ; }
    double b() const { return b_ ; }
    double a() const { return a_ ; }

    double r_, g_, b_, a_ ;
};

enum LineJoin { LineJoinMiter, LineJoinRound, LineJoinBevel } ;
enum LineCap { LineCapButt, LineCapRound, LineCapSquare } ;
enum LineStyle { SolidLine, DashLine, DotLine, DashDotLine, CustomDashLine } ;

class PenBase {

public:

    enum Type { None, Cosmetic } ;

    enum Flags { BrushFlag = 0x01, StrokeWidthFlag = 0x02, LineJoinFlag = 0x04,
                 LineCapFlag = 0x08, DashArrayFlag = 0x10, DashOffsetFlag = 0x20, MiterLimitFlag = 0x40 } ;

protected:

    PenBase(): flags_(0) {}

    friend class Context ;

    virtual Type type() const = 0 ;

protected:
    unsigned int flags_ ;
} ;

// A pen structure to hold stroke attributes
class Pen: public PenBase {

public:

    Pen( const Color &clr = Color(0, 0, 0), double strokeWidth = 1.0, LineStyle style = SolidLine ) ;

    Pen &setColor(const Color &brush) ;
    Pen &setLineWidth(double width) ;
    Pen &setMiterLimit(double limit) ;
    Pen &setLineJoin(LineJoin join) ;
    Pen &setLineCap(LineCap cap) ;
    Pen &setDashArray(int n, double *dashes) ;
    Pen &setDashOffset(double offset) ;
    Pen &setLineStyle(LineStyle dash) ;

private:

    friend class Context ;

    Type type() const { return PenBase::Cosmetic ; }

    double stroke_width_, miter_limit_ ;
    LineJoin line_join_ ;
    LineCap line_cap_ ;
    LineStyle line_style_ ;
    double dash_array_[DASH_ARRAY_LENGTH], dash_offset_ ;
    int dash_array_length_ ;
    Color brush_ ;
} ;

class EmptyPen: public PenBase {

    friend class Context ;

    Type type() const { return PenBase::None ; }
};

class Transform
{
public:

    Transform() ;
    Transform(double s0, double s1, double s2, double s3, double s4, double s5) ;

    static Transform inverse(const Transform &) ;
    static Transform flip(const Transform &src, bool horz, bool vert) ;
    static Transform multiply(const Transform &src1, const Transform &src2) ;
    static Transform identity() ;
    static Transform scaling(double sx, double sy) ;
    static Transform rotation(double theta) ;
    static Transform shearing(double theta) ;
    static Transform translation(double tx, double ty) ;
    static double expansion(const Transform &src) ;
    bool isRectilinear(const Transform &src) ;
    bool isEqual(const Transform &src1, const Transform &src2) ;
    void apply(double &x, double &y) ;

    Transform inverse() const { return Transform::inverse(*this); }
    friend Transform operator * ( const Transform &t1, const Transform &t2 ) {
        return Transform::multiply(t1, t2) ;
    }

    double m[6] ;
} ;

enum FillRule { EvenOddFillRule, NonZeroFillRule } ;

// abstract class for all brush type
class Brush {
public:

    void setFillRule(FillRule rule) ;
    void setFillOpacity(double opacity) ;

protected:

    Brush(): fill_rule_(EvenOddFillRule), flags_(0), fill_opacity_(1.0) {}

    friend class Context ;
    enum BrushType { Solid, LinearGradient, RadialGradient, Pattern, None } ;

    virtual BrushType type() const = 0 ;

public:

    enum Flags { FillRuleFlag = 0x01, FillOpacityFlag = 0x02, SpreadFlag = 0x04, UnitsFlag = 0x08, TransformFlag = 0x10 } ;

    unsigned int flags_ ;
    FillRule fill_rule_ ;
    double fill_opacity_ ;
} ;


class SolidBrush: public Brush {

public:

    SolidBrush(const Color &clr): clr_(clr) {}

private:

    friend class Context ;

    BrushType type() const { return Solid ; }

    Color clr_ ;
} ;

class GradientBrush: public Brush {

public:

    enum SpreadMethod { PadSpread, RepeatSpread, ReflectSpread } ;
    enum Units { UserSpaceOnUse, ObjectBoundingBox } ;

    void setSpread(SpreadMethod method) { sm_ = method ; flags_ |= SpreadFlag ; }
    void setTransform(const Transform &trans) { tr_ = trans ; flags_ |= TransformFlag ; }
    void setUnits(Units un) { gu_ = un ; flags_ |= UnitsFlag ; }

    GradientBrush &addStop(double offset, const Color &clr) {
        stops_.push_back(Stop(offset, clr)) ;
        return *this ;
    }

protected:

    GradientBrush(): sm_(PadSpread) {}

private:

    struct Stop {
        Stop(double offset, const Color &clr): offset_(offset), clr_(clr) {}
        double offset_ ;
        Color clr_ ;
    } ;

    friend class Context ;

    std::vector<Stop> stops_ ;
    SpreadMethod sm_ ;
    Transform tr_ ;
    Units gu_ ;

} ;

class HollowBrush: public Brush {

protected:

    HollowBrush() {}

private:

    friend class Context ;

    BrushType type() const { return None ; }
} ;

class LinearGradientBrush: public GradientBrush {

public:

    LinearGradientBrush(double x0, double y0, double x1, double y1, Units units = UserSpaceOnUse):
        x0_(x0), y0_(y0), x1_(x1), y1_(y1) { setUnits(units) ;}

private:

    friend class Context ;
    BrushType type() const { return LinearGradient ; }

    double x0_, y0_, x1_, y1_ ;
} ;

class RadialGradientBrush: public GradientBrush {

public:

    RadialGradientBrush(double cx, double cy, double r, double fx = 0, double fy = 0, Units units = UserSpaceOnUse):
        cx_(cx), cy_(cy), fx_(fx), fy_(fy), r_(r)  { setUnits(units) ; }

private:

    friend class Context ;
    BrushType type() const { return RadialGradient ; }

    double cx_, cy_, fx_, fy_, r_ ;
} ;

enum FontStyle { NormalFontStyle, ObliqueFontStyle, ItalicFontStyle } ;
enum FontWeight {	NormalFontWeight, BoldFontWeight } ;

class Font {
public:

    Font(const std::string &familyName, double pts) ;

    Font & setStyle(FontStyle style) { style_ = style  ; return *this ; }
    Font & setWeight(FontWeight weight) { weight_ = weight ; return *this ;}
    Font & setSize(double pts) { sz_ = pts ; return *this ; }
    Font & setFamily(const std::string &familyName ) { family_ = familyName ; return *this ; }

    FontStyle style_ ;
    FontWeight weight_ ;
    double sz_ ;
    std::string family_ ;
} ;



// A structure to create arbitrary shapes

class PathData ;
class Font ;

class Path
{
public:

    Path() ;
    ~Path() ;

    // See SVG 1.1 Path specification (http://www.w3.org/TR/SVG/paths.html)

    Path & moveTo(double x, double y) ;
    Path & moveToRel(double x, double y) ;

    Path & lineTo(double x, double y) ;
    Path & lineToRel(double x, double y) ;

    Path & lineToHorz(double x) ;
    Path & lineToHorzRel(double x) ;

    Path & lineToVert(double y) ;
    Path & lineToVertRel(double y) ;

    Path & curveTo(double x, double y, double x1, double y1, double x2, double y2) ;
    Path & curveToRel(double x, double y, double x1, double y1, double x2, double y2) ;

    Path & quadTo(double x, double y, double x1, double y1) ;
    Path & quadToRel(double x, double y, double x1, double y1) ;

    Path & smoothCurveTo(double x, double y, double x1, double y1) ;
    Path & smoothCurveToRel(double x, double y, double x1, double y1) ;

    Path & smoothQuadTo(double x, double y) ;
    Path & smoothQuadToRel(double x, double y) ;

    Path & arcTo(double rx, double ry, double angle, bool largeArcFlag, bool sweepFlag, double x, double y) ;
    Path & arcToRel(double rx, double ry, double angle, bool largeArcFlag, bool sweepFlag, double x, double y) ;

    Path & closePath() ;

    Path & addEllipse(double x0, double y0, double r1, double r2) ;
    // The arc is traced along the perimeter of the ellipse bounded by the specified rectangle.
    // The starting point of the arc is determined by measuring clockwise from the x-axis of the
    // ellipse (at the 0-degree angle) by the number of degrees in the start angle.
    // The endpoint is similarly located by measuring clockwise from the starting point by the
    // number of degrees in the sweep angle.
    Path & addArc(double x0, double y0, double r1, double r2, double startAngle, double sweepAngle) ;
    Path & addRect(double x0, double y0, double w, double h) ;
    Path & addRoundedRect(double x0, double y0, double w, double h, double xrad, double yrad) ;
    Path & addPath(const Path &other) ;
    Path & addText(const std::string &str, double x0, double y0, const Font &font) ;

    // path bounding box
    void extents(double &x0, double &y0, double &x1, double &y1) const ;

    // return a flattened version of the path
    Path flattened() const ;

private:

    friend class Context ;
    void cairo_path(void *cr_) const ;

    void setData(const boost::shared_ptr<PathData> &data) ;

    boost::shared_ptr<PathData> data ;
} ;


class PatternBrush ;

enum ViewBoxAlign {
    NoViewBoxAlign, XMinYMin, XMidYMin, XMaxYMin, XMinYMid, XMidYMid, XMaxYMid,
    XMinYMax, XMidYMax, XMaxYMax
} ;

enum ViewBoxPolicy {
    MeetViewBoxPolicy, SliceViewBoxPolicy
} ;

enum TextAlignFlags {
    AlignLeft = 0x01, AlignRight = 0x02, AlignTop = 0x04, AlignBottom = 0x08, AlignHCenter = 0x10, AlignVCenter = 0x20, AlignBaseline = 0x40
} ;

// rendering context used for all drawing operations

class Context {

public:

    // create a graphics context on the given surface
    Context(Surface *surf) ;
    ~Context() ;

    void save() ; // save context (push state)
    void restore() ; // restore conext (pop state)

    void pushTransform(const Transform &tr) ;
    void popTransform() ;

    void setViewBox(double w, double h, ViewBoxPolicy pc = MeetViewBoxPolicy, ViewBoxAlign align = XMidYMid) ;
    void setViewBox(double x, double y, double w, double h, ViewBoxPolicy pc = MeetViewBoxPolicy, ViewBoxAlign align = XMidYMid) ;

    Context & setPen(const Pen &pen) ;
    Context & setBrush(const SolidBrush &brush) ;
    Context & setBrush(const LinearGradientBrush &brush) ;
    Context & setBrush(const RadialGradientBrush &brush) ;
    Context & setBrush(const PatternBrush &brush) ;
    Context & setFont(const Font &font) ;

    Context & clearBrush() ;
    Context & clearPen() ;

    Context & setAntialias(bool antiAlias = true) ;

    Context & setClipRect(double x0, double y0, double w, double h) ;
    Context & setClipPath(const Path &p) ;

    Context & drawLine(double x0, double y0, double x1, double y1) ;
    Context & drawRect(double x0, double y0, double w, double h) ;
    Context & drawPath(const Path &path) ;

    Context & drawPolyline(double *pts, int nPts) ;
    Context & drawPolygon(double *pts, int nPts) ;
    Context & drawCircle(double cx, double cy, double r);
    Context & drawEllipse(double xp, double yp, double ax, double ay);

    Context & drawText(const std::string &textStr, double x0, double y0) ;
    Context & drawText(const std::string &textStr, double x0, double y0, double width, double height, unsigned int flags) ;

    void boundingRect(const std::string &textStr, double &w, double &h, double &x_bearing, double &y_bearing) ;

    // draw the image inside the bounding box (x0, y0, w, h)
    Context &drawImage(const cv::Mat &im, double x0, double y0, double w, double h,
                   ViewBoxPolicy policy = MeetViewBoxPolicy, ViewBoxAlign align = XMidYMid,
                   double opacity = 1.0 ) ;
    // same but with a png image
    Context &drawImage(const std::string &pngImageFile, double x0, double y0, double w, double h,
                   ViewBoxPolicy policy = MeetViewBoxPolicy, ViewBoxAlign align = XMidYMid,
                   double opacity = 1.0 ) ;

private:

    void linePath(double x0, double y0, double x1, double y1) ;
    void rectPath(double x0, double y9, double w, double h) ;
    void path(const Path &path) ;
    void polylinePath(double *pts, int n, bool) ;

    friend struct PenState ;
    friend struct BrushState ;

    void set_cairo_stroke(const Pen &p) ;
    void set_cairo_fill(const Brush &b) ;
    void cairo_apply_linear_gradient(const LinearGradientBrush &lg) ;
    void cairo_apply_radial_gradient(const RadialGradientBrush &rg) ;
    void cairo_apply_pattern(const PatternBrush &pat) ;
    void cairo_apply_font(const Font &font) ;
    void set_object_bbox(double x, double y, double w, double h) ;
    void fill_stroke_shape();

    static Transform getViewBoxTransform(double sw, double sh, double vwidth, double vheight, double vx, double vy, ViewBoxPolicy policy, ViewBoxAlign align)  ;
    static void constrainViewBox(double width_, double height_, double &origx, double &origy, double &origw, double &origh, ViewBoxPolicy policy, ViewBoxAlign align) ;

    void *cr_ ;
    Surface *eSurf ;
    double vboxx, vboxy, vboxw, vboxh ; // object bounding box ;


    struct State {
        State() ;

        boost::shared_ptr<PenBase> cpen_ ;
        boost::shared_ptr<Brush> cbrush_ ;
        Font cfont_ ;
    };

    std::deque<State> state_ ;


};

// A pattern brush is used for filling shapes with patterns. It is a grahics context where one can
// draw arbitrary shapes

class PatternBrush: public Brush {

public:

    enum Units { UserSpaceOnUse, ObjectBoundingBox } ;

    PatternBrush(PatternSurface &surf, Units units = UserSpaceOnUse):
        pu_(units), surf_(surf)  {}

    void setTransform(const Transform &trans) { tr_ = trans ; }

private:

    friend class Context ;

    BrushType type() const { return Pattern ; }

    PatternSurface &surf_ ;
    Transform tr_ ;
    Units pu_ ;
    double width_, height_ ;

} ;



}

             } // namespace cpm

#endif
