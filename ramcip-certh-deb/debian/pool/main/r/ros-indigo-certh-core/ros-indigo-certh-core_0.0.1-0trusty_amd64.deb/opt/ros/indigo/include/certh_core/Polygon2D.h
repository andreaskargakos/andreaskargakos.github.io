#ifndef __POLYGON_2D_H__
#define __POLYGON_2D_H__

#include <certh_core/config.h>

#include <certh_core/Rectangle2D.h>
#include <certh_core/Triangle2D.h>

#include <deque>

namespace certh_core {

class TriangleMesh2D ;

class Polygon2d
{
    public:

    Polygon2d(): plist(), trg(NULL) {}
    Polygon2d(const Point2d *p, int n) ;
    Polygon2d(const Polygon2d &other): plist(other.plist), trg(NULL) {}
    Polygon2d(int n): plist(n), trg(NULL) {}
    Polygon2d(const Triangle2d &tr) ;
    ~Polygon2d() ;

    void clear() { plist.clear() ; }

    int getNumPoints() const { return plist.size() ; }
  
    void addPoint(const Point2d &p) { plist.push_back(p) ; }
    Point2d &getPoint(int i) { return plist[i] ; }
    Point2d &operator [] (int i) { return plist[i] ; }
    const Point2d &operator [] (int i) const
        { return (const Point2d &)plist[i] ; }
  
    double area() const ;
    Rectangle2d boundingBox() const ;

    enum ICode { PtInPolygon, PtOutPolygon, PtOnEdge, PtOnVertex } ;

    ICode whereIs(const Point2d &p) ;

    bool contains(const Point2d &p) ;
    bool contains(float x, float y) { return contains(Point2d(x,y)) ; }

    friend std::ostream &operator << (std::ostream &strm, const Polygon2d &p) ;
    friend std::istream &operator >> (std::istream &strm, Polygon2d &p) ;

private:

    std::deque<Point2d> plist ;

    TriangleMesh2D *trg ;
} ;


inline Polygon2d::Polygon2d(const Triangle2d &tr): plist(), trg(NULL)
{
    addPoint(tr.p1) ;
    addPoint(tr.p2) ;
    addPoint(tr.p3) ;
}


}

#endif
