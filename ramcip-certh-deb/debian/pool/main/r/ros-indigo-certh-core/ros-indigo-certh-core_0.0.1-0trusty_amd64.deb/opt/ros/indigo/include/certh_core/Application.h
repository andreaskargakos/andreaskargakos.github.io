#ifndef __APPLICATION_H__
#define __APPLICATION_H__

#include <certh_core/config.h>
#include <certh_core/Logger.h>
#include <certh_core/ProgressStream.h>
#include <certh_core/ApplicationSettings.h>

#include <boost/filesystem.hpp>

namespace certh_core {

// a container for some global variables of an application instance

class Logger ;
class CommandLineParser ;

class Application {

public:
    // the constructor will parse the commandline and will initialize global variables below to reasonable values

    Application(const std::string &name, int &argc, char **argv) ;

    ~Application() ;

    /*
     * Returns the global instance of application settings object. The program will look for the configuration file in the following locations:
     *
     * 1. The command line for the --config parameter pointing to the file path.
     * 2. <home_path>/.config/<app_name>/config.xml (Unix) or <user_dir>/<app_name>/config.xml on (Windows); This is the default location.
     * 3. <data_dir>/config.xml (see below).
     *
     * In case of failure it will create an empty file in the default location.
     *
     */

    static ApplicationSettings &settings()  {
        assert(instance_) ;
        return *instance_->settings_ ;
    }

    /*
     *  Returns a platform independent location of application data. The program will search for the data folder in the following locations:
     *
     * 1. The command line for the --data parameter pointing to the directory.
     * 2. If the executable is located inside a source folder (<source_root>/build<suffix>/bin/<executable>) it will check the existence
     *    of <source_root>/data or <source_root>/tests/data/.
     * 3. <user_data>/<app_name>/data/ where <user_data> is ~/.share/data/ on Unix and CSIDL_APPDATA on Windows (e.g. C:\Users\<user>\appData\roaming\). This is
     *    the default location.
     * 4. <home_path>/.<app_name>/data/  (Unix)
     * 5. Environment variable <APP_NAME>_DATA_DIR (uppercase)
     *
     * If none found the folder in the default location will be created.
     */

    static boost::filesystem::path dataFolder() {
        assert( instance_) ;
        return instance_->data_dir_ ;
    }

    Application *instance() { return instance_ ; }

    /*
     *  Returns the application global logger object. If the application has not been initialized a default logger will be returned.
     *
     *  Otherwise the program will parse the settings file for a <Logging> section.
     *
     */

    static Logger &logger() ;

private:

    bool setupDataDir(int &argc, char **argv) ;
    boost::filesystem::path setupConfig(int &argc, char **argv) ;

    Logger *logger_ ;                // the application logger
    ProgressStream *prog_stream_ ;   // the application progress stream
    boost::filesystem::path data_dir_ ;          // application data folder
    ApplicationSettings *settings_ ; // application settings
    std::string app_name_ ;
    CommandLineParser *cmd_parser_ ;

    static Application *instance_ ;  // single instance of the application

};

}

#endif
