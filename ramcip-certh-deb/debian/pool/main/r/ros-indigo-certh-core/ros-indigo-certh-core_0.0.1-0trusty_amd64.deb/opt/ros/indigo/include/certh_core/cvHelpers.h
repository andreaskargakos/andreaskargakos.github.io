#ifndef __CV_HELPERS_H__
#define __CV_HELPERS_H__

#include <certh_core/config.h>
#include <certh_core/Point.h>

#include <opencv2/opencv.hpp>

#include <boost/shared_array.hpp>

namespace certh_core {

// compute pixels on the line defined by points p1, p2
void getScanLine(const Point &p1, const Point &p2, std::vector<Point> &pts) ;

// compute image gradient of a color image. For each pixel the maximum magnitude gradient from the 3 color bands
// is selected. Gradient magnitude is also thresholded using the provided threshold.

void computeGradient(const cv::Mat &clr, cv::Mat &mag, cv::Mat &ang, double gradMagThreshold) ;
void computeGradientField(const cv::Mat &clr, cv::Mat &gx, cv::Mat &gy, double gradMagThreshold) ;

// calls cv::imwrite but formats path first using sprintf
void imwritef(const cv::Mat &im, const char *format, ... ) ;

void makeGaborFilterBank(int nOctaves, int nAngles, double sigma, std::vector<cv::Mat> &kernels) ;
void applyGaborFilterBank(const cv::Mat &src, std::vector<cv::Mat> &kernels, std::vector<cv::Mat> &responses) ;

// find connected components in a binary image. The components are returned as a label image (unsigned long).
// nc can be 4 for 4-connected and 8 for 8-connected regions
unsigned int connectedComponents(const cv::Mat &src, cv::Mat &labelImage, int nc = 8) ;

// class for iterating over regions/blobs returned by connected components
class RegionIterator {

public:

    RegionIterator(const cv::Mat &src): src_(src) {
        reset(src) ;
    }

    RegionIterator(const RegionIterator &other): src_(other.src_), data_(other.data_), it_(other.it_) {}
    RegionIterator(): src_(cv::Mat()), data_(new ContainerType), it_(data_->end()) {}

    bool operator == (const RegionIterator &other) const { return it_ == other.it_ ; }
    bool operator != (const RegionIterator &other) const { return it_ != other.it_ ; }

    operator int () const { return it_ != data_->end() ; }
    RegionIterator & operator++()  { ++it_ ; return *this ; }
    RegionIterator operator++(int) { RegionIterator tmp(*this) ; ++it_; return tmp ; }

    // return area of the region
    unsigned int area() const { return it_->second.area_ ; }

    // return outer contour of the region
    std::vector<cv::Point> contour() const ;

    // return label of the region
    unsigned long label() const { return it_->second.label_; }

    // return bounding rectangle
    cv::Rect rect() const { return it_->second.rect_ ; }

    // return mask of the same size as the source image with region pixels set to 255
    cv::Mat mask() const ;

private:

    void reset(const cv::Mat &src) ;

    struct RegionData {
        unsigned long label_ ;
        cv::Rect rect_ ;
        unsigned int area_ ;
    };

    typedef std::map<unsigned long, RegionData> ContainerType ;

    boost::shared_ptr<ContainerType> data_ ;
    ContainerType::const_iterator it_ ;
    cv::Mat src_ ;
};

// performs connected components analysis on the source binary image (CV_8UC1) and finds the largest blob. It returns
// an iterator to the extracted region list pointing to the found region.

RegionIterator findLargestBlob(const cv::Mat &src,  unsigned int minArea = 0) ;

// create a colormapped image from depth 16bit image
cv::Mat depthViz(const cv::Mat &depth, ushort minv_ =0, ushort maxv_ = 0) ;

}


#endif



