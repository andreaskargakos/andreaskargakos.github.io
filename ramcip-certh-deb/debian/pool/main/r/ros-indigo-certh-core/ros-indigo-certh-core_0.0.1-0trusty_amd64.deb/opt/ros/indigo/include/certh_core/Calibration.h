#ifndef __CAMERA_UTILS_H__
#define __CAMERA_UTILS_H__

#include <certh_core/config.h>

#include <vector>
#include <opencv2/opencv.hpp>
#include <boost/shared_ptr.hpp>

#include <Eigen/Geometry>

namespace certh_core {
// interface for defininh custom calibration patterns

class CalibrationPattern
{
public:
    CalibrationPattern() {}

    // find calibration targets on image and associated 3d coordinates
    // return false if no pattern found
    virtual bool findPoints(const cv::Mat &im, std::vector<cv::Point2f> &pts, std::vector<cv::Point3f> &objs) = 0 ;

};

// wrapper for OpenCV calibration pattern algorithms

class OCVCalibrationPattern: public CalibrationPattern
{
public:

    enum Type { Chessboard, CirclesGrid, AsymmetricCirclesGrid } ;

    OCVCalibrationPattern(const cv::Size &boardSize, const cv::Size &tileSize, Type ptype = Chessboard):
        board_size_(boardSize), tile_size_(tileSize), type_(ptype) {}

    bool findPoints(const cv::Mat &im, std::vector<cv::Point2f> &pts, std::vector<cv::Point3f> &objs) ;

    void draw(cv::Mat &img, const std::vector<cv::Point2f> &corners, bool pattern_found);

private:

    cv::Size board_size_, tile_size_ ;
    Type type_ ;
};

enum AprilTagFamily { AprilTag36h11, AprilTag25h9, AprilTag16h5 } ;

// detector of apriltag patterns based on http://april.eecs.umich.edu/wiki/index.php/AprilTags

class AprilTagDetector {
public:

    struct Result {
        uint64_t id ;        // tag id
        cv::Point2f pts[4] ; // detected corners of tag box (clockwise)
    };

    AprilTagDetector(AprilTagFamily family = AprilTag36h11) ;

    void detect(const cv::Mat &imc, std::vector<Result> &results) ;

    void draw(cv::Mat &im, const std::vector<Result> &results) ;

    ~AprilTagDetector() ;

private:

    void *tf_, *td_ ;
};

// a grid pattern of apriltags

class AprilTagGridPattern: public CalibrationPattern
{
public:

    // boardSize: number of tiles in each dimension, tileSize: size of the tile in meteres, tileBorder: border between tiles in meters
    AprilTagGridPattern(const cv::Size &boardSize, float tileSize, float tileBorder, AprilTagDetector &detector);

    bool findPoints(const cv::Mat &im, std::vector<cv::Point2f> &pts, std::vector<cv::Point3f> &objs) ;

    // creates a pattern of given dimensions to be used as a calibration target
    // tagFolder: folder where tag pattern images are located (downloaded from website)
    // outSvg: filename of the resulting SVG image.

    static void makePattern36H11(const std::string &tagFolder, const std::string &outSvg,
                          const cv::Size &boardSize, float tileSize, float tileOffset) ;

    void draw(cv::Mat &im, std::vector<cv::Point2f> &pts, const std::vector<cv::Point3f> &objs);

protected:

    cv::Size board_size_ ;
    float tile_size_, tile_border_ ;
    AprilTagDetector &detector_ ;

};


class PinholeCamera
{
public:
    PinholeCamera() {}
    PinholeCamera(double fx, double fy, double cx, double cy, const cv::Size &isz): fx_(fx), fy_(fy), cx_(cx), cy_(cy), sz_(isz) {}

    cv::Mat getMatrix() const {
        cv::Mat_<double> mat = cv::Mat_<double>::zeros(3, 3) ;
        mat(0, 0) = fx_ ; mat(0, 2) = cx_ ;
        mat(1, 1) = fy_ ; mat(1, 2) = cy_ ;
        mat(2, 2) = 1.0 ;
        return mat ;
    }

    cv::Mat getDistortion() const {
        return dist_ ;
    }

    cv::Point2d project(const cv::Point3d& xyz) const {
        return cv::Point2d(fx_ * xyz.x / xyz.z + cx_, fy_ * xyz.y / xyz.z + cy_) ;
    }

    cv::Point3d backProject(const cv::Point2d& uv) const {
        return cv::Point3d((uv.x - cx_)/fx_, (uv.y - cy_)/fy_, 1.0) ;
    }

    cv::Mat rectifyImage(const cv::Mat& raw, int interpolation = cv::INTER_LINEAR) const ;
    cv::Mat unrectifyImage(const cv::Mat& rectified, int interpolation = cv::INTER_LINEAR) const ;

    cv::Point2d rectifyPoint(const cv::Point2d &uv_raw) const ;
    cv::Point2d unrectifyPoint(const cv::Point2d &uv_rect) const ;

    double fx() const { return fx_ ; }
    double fy() const { return fy_ ; }
    double cx() const { return cx_ ; }
    double cy() const { return cy_ ; }

    unsigned int width() const { return sz_.width ; }
    unsigned int height() const { return sz_.height ; }

    cv::Size sz() const { return sz_ ; }

    bool read(const std::string &fname)
    {
        cv::FileStorage fs ;

        if ( !fs.open(fname, cv::FileStorage::READ) ) return false ;

        cv::Mat intrinsics, distortion;

        fs["image_width"] >> sz_.width ;
        fs["image_height"] >> sz_.height ;

        fs["camera_matrix"] >> intrinsics;
        fs["distortion_coefficients"] >> distortion;

        fx_ = intrinsics.at<float>(0, 0) ;
        fy_ = intrinsics.at<float>(1, 1) ;
        cx_ = intrinsics.at<float>(0, 2) ;
        cy_ = intrinsics.at<float>(1, 2) ;

        return true ;

    }

protected:

    double fx_, fy_, cx_, cy_ ;
    cv::Mat dist_ ;
    cv::Size sz_ ;

};

// estimate camera pose using OpenCV PnPRansac

Eigen::Affine3d estimatePose(const std::vector<cv::Point2f> &imagePts, const std::vector<cv::Point3f> &objPts,
                                    const PinholeCamera &cam, const Eigen::Affine3d &a, bool usePrevious, double &err) ;

// estimate pose of planar target
Eigen::Affine3d estimatePosePlanar(const std::vector<cv::Point2f> &imagePts, const std::vector<cv::Point3f> &objPts,
                            const PinholeCamera &cam, double &err) ;


Eigen::Matrix4d rodriguesToAffine(const cv::Mat &rvec, const cv::Mat &tvec) ;
void affineToRodrigues(const Eigen::Matrix4d &mat, cv::Mat &rvec, cv::Mat &tvec) ;

}

#endif
