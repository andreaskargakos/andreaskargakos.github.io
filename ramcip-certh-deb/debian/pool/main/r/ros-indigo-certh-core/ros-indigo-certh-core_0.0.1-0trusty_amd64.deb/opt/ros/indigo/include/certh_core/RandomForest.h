#ifndef __RANDOM_FOREST_H__
#define __RANDOM_FOREST_H__

#include <certh_core/RandomForestModels.h>
#include <certh_core/BinaryStream.h>
#include <certh_core/ProgressStream.h>

#include <vector>

#include <boost/random.hpp>

#include <float.h>

namespace certh_core {

struct RFTrainingParameters {
    unsigned int max_depth ;            // maximum depth of each tree
    unsigned int num_random_samples ;   // number of random features to test for each node
    double gain_threshold ;             // threshold of gain achieved afetr splitting. if less than threshold node will be split.
    unsigned int num_trees ;            // number of trees in the forest
    unsigned int min_pts_per_leaf ;     // minimum number of data points falling on each leaf node
    unsigned int num_samples_per_tree ; // number of samples randomly selected from the original dataset to pass to each tree (with replacement)
    unsigned int num_thresholds_per_sample ;    // number of threshold to test for each feature

    RFTrainingParameters():
        max_depth(5), num_random_samples(50), gain_threshold(0.01), num_trees(10),
        min_pts_per_leaf(5), num_samples_per_tree(1000), num_thresholds_per_sample(20) {}
};

// A random forest parametrized by a weak learner/feature L, and training data model M (e.g. histogram for each node)
// Learner and model should adhere to concepts above

template<class F, class M, class RNG = boost::random::mt19937>
class RandomForest
{
public:

    typedef F feature_t ;
    typedef typename feature_t::dataset_t dataset_t ;
    typedef typename dataset_t::sample_idx_t sample_idx_t ;
    typedef std::vector<sample_idx_t> subset_t ;

    RandomForest() ;
    ~RandomForest() ;

    typedef RFTrainingParameters TrainingParameters ;

    // trains a forest on the dataset with given parameters
    void train(const dataset_t &ds, const TrainingParameters &params) ;

    // pass a dataset through the forest to assign each feature to a leaf in the forest
    void apply(const dataset_t &ds, std::vector<std::vector< unsigned int > > &nodes_for_leafs) ;

    uint32_t numTrees() const { return trees_.size() ; }

    // read/write

    void read(BinaryStream &strm) ;
    void write(BinaryStream &strm) ;


    struct Node {

        enum Type { Leaf = 0, Split = 1, Empty = 2 } ;

        Type type_ ; // node is leaf
        feature_t feature_ ; // feature for this node
        M data_ ;       // training data for this node
        double threshold_ ;// threshold

        Node(): type_(Empty) {}

        void write(BinaryStream &bs)
        {
            bs.write((uint8_t)type_) ;
            if ( type_ == Split ) {
                feature_.write(bs) ;
                bs.write(threshold_) ;
            }
            else if ( type_ == Leaf )
                data_.write(bs) ;
        }

        void read(BinaryStream &bs)
        {
            uint8_t t ;
            bs.read(t) ;

            type_ = (Type)t ;

            if ( type_ == Split ) {
                feature_.read(bs) ;
                bs.read(threshold_) ;
            }
            else if ( type_ == Leaf )
                data_.read(bs) ;
        }


        void makeLeaf(const M &model) {
            data_.aggregate(model) ;
            type_ = Leaf ;
        }

        void makeSplit(const feature_t &wl, double thresh, const M &model) {
            data_ = model ;
            feature_ = wl ;
            threshold_ = thresh ;
            type_ = Split ;
        }

    } ;

    class Tree {

    public:
        Tree(unsigned int depth): depth_(depth) {
            nodes_ = new Node [(1 << depth) - 1] ;
        }

        ~Tree() { delete [] nodes_ ; }

        void train(const dataset_t &ds, subset_t &subset, unsigned int bidx, unsigned int eidx,
                   const TrainingParameters &params, RNG &rng) ;
        void apply(const dataset_t &ds, std::vector<unsigned int> &leaf_node_indices) ;

        const Node &getNode(uint32_t idx) const { return nodes_[idx] ; }
        uint32_t numNodes() const { return (1 << depth_) - 1 ; }

        void write(BinaryStream &strm) {
            write_node(0, strm) ;
        }

        void read(BinaryStream &strm) {
            read_node(0, strm) ;
        }


    private:

        struct TrainingContext {
            TrainingContext(const dataset_t &ds, const TrainingParameters &params, subset_t &sub, RNG &g):
                params_(params), ds_(ds), sub_(sub), rng_(g) {}
            const TrainingParameters &params_ ;
            const dataset_t &ds_ ;
            subset_t &sub_ ;
            RNG &rng_ ;
        };

        struct ApplyContext {
            ApplyContext(const dataset_t &ds, subset_t &sub):
                ds_(ds), sub_(sub) {}
            const dataset_t &ds_ ;
            subset_t &sub_ ;
        };


        void split(TrainingContext &ctx, unsigned int node, unsigned int bidx, unsigned int eidx, unsigned int depth) ;
        void visit(ApplyContext &ctx, unsigned int node, unsigned int bidx, unsigned int eidx, std::vector<unsigned int> &leaf_node_indices) ;
        static int partition(std::vector<bool>& decisions, subset_t&  subset, unsigned int bidx, unsigned int eidx) ;

        void read_node(unsigned int node, BinaryStream &strm)  ;
        void write_node(unsigned int node, BinaryStream &strm) ;

        Node *nodes_ ;
        uint32_t depth_ ;
    };

    RNG rng_ ;

public:

    std::vector<Tree *> trees_ ;
    uint32_t depth_ ;

};


using std::vector ;

// specialization for the case of a classifier
template<typename L, typename S>
class RandomForestClassifier: public RandomForest<L, HistogramModel<S> > {
public:

    typedef typename L::dataset_t dataset_t ;
    typedef HistogramModel<S> model_t ;
    typedef RandomForest<L, model_t> forest_t ;

    void classify(dataset_t &ds)
    {
       vector<vector<unsigned int> > leafs ;

       this->apply(ds, leafs) ;

       for(int i=0 ; i<ds.numSamples() ; i++ )
       {
            HistogramModel<S>  h;

            for (int t = 0; t < this->numTrees() ; t++)
            {
               int leaf_idx = leafs[t][i];

               h.aggregate(this->trees_[t]->getNode(leaf_idx).data_);
            }

           unsigned cl = h.highest() ;

           ds.setLabel(i, cl) ;
       }

   }

} ;


template<class L, class M, class R>
RandomForest<L, M, R>::RandomForest()
{

}

template<class L, class M, class R>
void RandomForest<L, M, R>::read(BinaryStream &strm)
{
    uint32_t n_trees, max_depth ;

    strm >> n_trees >> depth_;

    for ( int i = 0; i < n_trees; i++ )
    {
        Tree *t = new Tree(depth_) ;
        t->read(strm) ;
        trees_.push_back(t) ;
    }

}

template<class L, class M, class R>
void RandomForest<L, M, R>::write(BinaryStream &strm)
{
    strm << (uint32_t)trees_.size() << depth_ ;

    for ( int i = 0; i < trees_.size() ; i++ )
        trees_[i]->write(strm) ;
}

template<class L, class M, class R>
RandomForest<L, M, R>::~RandomForest()
{
    for( int i=0 ; i<trees_.size() ; i++ )
        delete trees_[i] ;
}

template<class R>
struct std_rng : std::unary_function<unsigned, unsigned> {
    R &state_;
    unsigned operator()(unsigned i) {
        boost::uniform_int<> rng(0, i - 1);
        return rng(state_);
    }
    std_rng(R &state) : state_(state) {}
};

template<class L, class M, class R>
void RandomForest<L, M, R>::train(const dataset_t &ds, const TrainingParameters &params)
{

    depth_ = params.max_depth ;

    sample_idx_t n = ds.numSamples() ;

#pragma omp parallel for
    for ( int i = 0; i < params.num_trees; i++ )
    {
        R r ;
        r.seed(clock()) ;

        subset_t subset ;
        sample_with_replacement(std::min((sample_idx_t)params.num_samples_per_tree, n), n, subset) ;

        Tree *t = new Tree(depth_) ;
        t->train(ds, subset, 0, subset.size(), params, r) ;
        trees_.push_back(t) ;

    }
}


template<class L, class M, class R>
void RandomForest<L, M, R>::apply(const dataset_t &ds, std::vector< std::vector<unsigned int> > &leaf_node_indices)
{
    leaf_node_indices.resize(trees_.size()) ;


#pragma omp parallel for
    for ( int i = 0; i < trees_.size(); i++ )
    {
        Tree *t = trees_[i] ;

        std::vector<unsigned int> indices ;
        uint64_t n = ds.numSamples() ;
        indices.resize(n) ;

        t->apply(ds, indices) ;
        leaf_node_indices[i] = indices ;
    }

}

template<class L, class M, class R>
void RandomForest<L, M, R>::Tree::read_node(unsigned int node, BinaryStream &strm)
{
    nodes_[node].read(strm) ;
    if ( nodes_[node].type_ == Node::Split )
    {
        read_node(2*node+1, strm) ;
        read_node(2*node+2, strm) ;
    }
}

template<class L, class M, class R>
void RandomForest<L, M, R>::Tree::write_node(unsigned int node, BinaryStream &strm)
{
    nodes_[node].write(strm) ;
    if ( nodes_[node].type_ == Node::Split )
    {
        write_node(2*node+1, strm) ;
        write_node(2*node+2, strm) ;
    }
}


template<class L, class M, class R>
void RandomForest<L, M, R>::Tree::train(const dataset_t &ds, subset_t &subset, unsigned int bidx, unsigned int eidx,
                                     const TrainingParameters &params, R &rng)
{
    TrainingContext ctx(ds, params, subset, rng) ;

    split(ctx, 0, bidx, eidx, 0) ;
}

template<class L, class M, class R>
void RandomForest<L, M, R>::Tree::apply(const dataset_t &ds, vector<unsigned int> &indices)
{
    int n = ds.numSamples() ;

    // initialize dataset subset to include all data points
    vector<sample_idx_t> subset ;

    subset.resize(n);

    for( unsigned int i=0 ; i<n ; i++ )
        subset[i] = i ;

    ApplyContext ctx(ds, subset) ;

    visit(ctx, 0, 0, n, indices) ;

}

template<class L, class M, class R>
void RandomForest<L, M, R>::Tree::visit(ApplyContext &ctx, unsigned int node, unsigned int bidx, unsigned int eidx, vector<unsigned int> &leaf_node_indices)
{
    Node &nd = nodes_[node];

    if ( nd.type_ == Node::Leaf ) {
        for (int i = bidx; i < eidx; i++)
            leaf_node_indices[ctx.sub_[i]] = node ;
    }
    else
    {
        if ( bidx != eidx )
        {
            unsigned int n = eidx - bidx ;

            vector<bool> decisions(n) ;

            for ( int i = bidx; i < eidx; i++ )
                decisions[i - bidx] = ( nd.feature_.response(ctx.ds_, ctx.sub_[i]) < nd.threshold_) ;

            int split_idx = partition(decisions, ctx.sub_, bidx, eidx) ;

            visit(ctx, node * 2 + 1, bidx, split_idx, leaf_node_indices) ;
            visit(ctx, node * 2 + 2, split_idx, eidx, leaf_node_indices) ;
        }
    }
}

// partition the dataset subset based on provided decisions (true goes left, false goes right)
template<class L, class M, class R>
int RandomForest<L, M, R>::Tree::partition(std::vector<bool>& decisions, subset_t&  subset, unsigned int bidx, unsigned int eidx)
{
    int i = (int)bidx;
    int j = int(eidx - 1);

    while (i != j)
    {
        if ( !decisions[i - bidx] )
        {
            bool d = decisions[i - bidx];
            unsigned int idx = subset[i];

            decisions[i - bidx] = decisions[j - bidx];
            subset[i] = subset[j];

            decisions[j - bidx] = d;
            subset[j] = idx;

            j--;
        }
        else i++ ;
    }

    return decisions[i-bidx] ? i + 1 : i ;
}

template<class L, class M, class R>
void RandomForest<L, M, R>::Tree::split(TrainingContext &ctx, unsigned int node, unsigned int bidx, unsigned int eidx, unsigned int depth)
{
    M pm ;
    feature_t bwl ;

    unsigned int nn = (1 << ctx.params_.max_depth) - 1 ;

    vector<bool> bdecisions, decisions ;
    vector<double> responses ;

    unsigned int n = eidx - bidx ;

    // compute model of the parent node

    for( int i=bidx ; i<eidx ; i++ )
        pm.aggregate(ctx.ds_, ctx.sub_[i]) ;

    if ( node >= nn/2 || eidx - bidx < ctx.params_.min_pts_per_leaf ) // reached recursion depth
    {
         nodes_[node].makeLeaf( pm ) ;
         return ;
    }

    double maxGain = -DBL_MAX, bestThresh ;
    bdecisions.resize(n) ;
    decisions.resize(n) ;
    responses.resize(n) ;

    // find the best partioning of the data subset

    for(int t=0 ; t<ctx.params_.num_random_samples ; t++ )
    {
        // randomize the feature

        feature_t wl ;
        wl.sample(ctx.ds_, ctx.rng_) ;

        // compute feature responses over the dataset

        double min_response = DBL_MAX, max_response = -DBL_MAX;

        for( unsigned int i=bidx ; i<eidx ; i++ )
        {
            unsigned data_idx = ctx.sub_[i] ;

            double res = wl.response(ctx.ds_, data_idx) ;

            min_response = std::min(min_response, res) ;
            max_response = std::max(max_response, res) ;

            responses[i-bidx] = res ;
        }

        // choose candidate thresholds and optimize

        M lm, rm ;

        boost::uniform_real<> dist_thresh(min_response, max_response) ;

        for ( unsigned int k=0 ; k<ctx.params_.num_thresholds_per_sample ; k++ )
        {
            double thresh = dist_thresh(ctx.rng_) ;

            for( unsigned int i=bidx ; i<eidx ; i++ )
            {
                unsigned data_idx = ctx.sub_[i] ;

                if ( responses[i-bidx] < thresh ) {
                    lm.aggregate(ctx.ds_, data_idx) ;
                    decisions[i - bidx] = true ;
                }
                else {
                    rm.aggregate(ctx.ds_, data_idx) ;
                    decisions[i - bidx] = false ;
                }
            }

            double gain = pm.gain(lm, rm) ;

            if ( gain >= maxGain )
            {
                maxGain = gain;
                bwl = wl ;
                std::copy(decisions.begin(), decisions.end(), bdecisions.begin()) ;
                bestThresh = thresh ;
            }

        }
    }


    if ( maxGain < ctx.params_.gain_threshold ) // leaf node
        nodes_[node].makeLeaf( pm ) ;
    else { // split node

        unsigned int split_idx = partition(bdecisions, ctx.sub_, bidx, eidx) ;

        nodes_[node].makeSplit( bwl, bestThresh, pm ) ;

        // split data subset and recurse to left and right node

        split(ctx, 2*node + 1, bidx, split_idx, depth + 1) ;
        split(ctx, 2*node + 2, split_idx, eidx, depth + 1) ;
    }
}

} // namespace certh_core






#endif
