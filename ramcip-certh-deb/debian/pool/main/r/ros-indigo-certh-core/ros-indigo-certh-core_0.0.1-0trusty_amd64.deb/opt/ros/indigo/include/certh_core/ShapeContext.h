#ifndef __SHAPE_CONTEXT_H__
#define __SHAPE_CONTEXT_H__

#include <certh_core/PointList2D.h>

namespace certh_core {

// Implementation of S. Belongie et al, "Shape Matching and Object Recognition Using Shape Contexts", PAMI, 2002

class ShapeContextMatcher {
public:
    struct Parameters {

        Parameters(): num_rings(4), num_wedges(8), r_inner(0.1), r_outer(2.0), outlier_error(0.05), outlier_frac(0.25), num_iter(20),
        beta(1.0), beta_anneal(1.0){}

        int num_rings ;     // radius bining
        int num_wedges ;    // number of wedges that each ring is subdivided (angle bining)
        double r_inner ;    // radius of innermost ring (normalized by mean distance)
        double r_outer ;    // radius of outermost ring (normalized by mean distance)
        double outlier_error ; // matching error when the point is flaged as outlier
        double outlier_frac ; //  number of dummy points as percentage of input points (i.e. percentage of outliers)
        int num_iter ;      // number of iterations
        double beta ;       // TPS regularization value
        double beta_anneal ; // regularization relaxation factor for each iteration
    } ;

    ShapeContextMatcher() {}
    ShapeContextMatcher(const Parameters &params): params_(params) {}

    // perform matching between point sets and return a list of matching points and a match score
    double match(const PointList2d &pts1, const PointList2d &pts2, std::vector<std::pair<int, int> > &matches ) ;

protected:

    cv::Mat computeSC(const PointList2d &pts, const std::vector<bool> &is_inlier, double &mean_dist) ;
    double matchSC(const cv::Mat &sc1, const cv::Mat &sc2, std::vector<int> &matches1, std::vector<int> &matches2) ;

private:

    Parameters params_ ;
};

}

#endif
