#ifndef __OPENFACE_FACE_DESCRIPTOR_H__
#define __OPENFACE_FACE_DESCRIPTOR_H__

#include <boost/filesystem.hpp>
#include <opencv2/opencv.hpp>
#include <Eigen/Core>

class DescriptorExtractorImpl ;

namespace certh_face {
namespace openface {

// Wrapper over openface pre-trained network for face descriptor extraction (http://cmusatyalab.github.io/openface/)

class DescriptorExtractor {

public:

    DescriptorExtractor() ;

    // init with path to the network file
    bool init(const boost::filesystem::path &net_path, bool use_cuda = true) ;

    // compute descriptor from RGB image
    Eigen::VectorXf compute(const cv::Mat &im) ;

private:

    boost::shared_ptr<DescriptorExtractorImpl> impl_ ;
};

}
}

#endif
