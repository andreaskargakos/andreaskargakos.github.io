#ifndef __ICUB_FACE_TRACKER_H__
#define __ICUB_FACE_TRACKER_H__

#include <boost/filesystem.hpp>
#include <certh_core/PointList2D.h>

namespace certh_face {
namespace icub {

// wrapper around binaries of face tracker (facial features + pose) obtained from
// http://ibug.doc.ic.ac.uk/resources/real-time-face-tracking-cuda-mmsys-2014/
//

class FacialLandmarkDetector {

public:

    // init with the root folder containing the executable and models directory

    bool init(const boost::filesystem::path &p) ;

    // detect landmarks on uncropped image, optionally returns roll-pitch-yaw in degrees

    bool detect(const cv::Mat &im, certh_core::PointList2d &pts, float *pose = 0) ;

    // draw result

    void draw(cv::Mat &im, const certh_core::PointList2d &pts) ;


private:

    boost::filesystem::path pexe_, pdata_ ;

};

}
}

#endif
