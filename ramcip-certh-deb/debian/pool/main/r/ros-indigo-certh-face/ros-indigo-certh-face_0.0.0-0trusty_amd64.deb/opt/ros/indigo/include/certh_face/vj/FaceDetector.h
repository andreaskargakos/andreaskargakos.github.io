#ifndef __FACE_DETECTOR_H__
#define __FACE_DETECTOR_H__

#include <string>

#include <opencv2/opencv.hpp>
#include <opencv2/objdetect/objdetect.hpp>

#include <boost/filesystem.hpp>

// wrapper over Viola-Jones detector (OpenCV implementation)

namespace certh_face {

namespace vj {

class FaceDetector
{
public:

    struct Parameters {

        Parameters(): eq_hist(false), scale_factor(1.1), min_neighbors(3),
            min_face_size(), max_face_size() {}
        bool eq_hist ;          // Equalize histogram of input before detection
        int min_neighbors ;     // Minimum neighbors of each detected rectangle
        double scale_factor ;   // The factor by which the search window is scaled between the subsequent scans,
                                // for example, 1.1 means increasing window by 10%
        cv::Size min_face_size ;
        cv::Size max_face_size ;
    } ;

    FaceDetector(): params_() {}
    FaceDetector(const Parameters &params): params_(params) {}

    // Call to load the cascade to memory. cascade_path may be a full path to the cascade file or a filename.
    // In the latter case the function will try to find the path based on the opencv installation directory and
    // operating system.

    bool init(const boost::filesystem::path &cascade_path) ;

    // detect faces optionally providing a search ROI
    bool detect(const cv::Mat &im, std::vector<cv::Rect> &faces, const cv::Rect &roi = cv::Rect()) ;

    // draw detected faces
    void draw(cv::Mat &im, const std::vector<cv::Rect> &faces, const cv::Vec3i &clr = cv::Vec3i(255, 255, 255)) ;

    // heuristic to predict approximate location of eyes given the face box returned by a frontal detector
    static void predictEyeLocations(const cv::Rect &box, cv::Rect &left_eye, cv::Rect &right_eye) ;

    // heuristic to predict approximate location of nose given the face box returned by a frontal detector
    static void predictNoseLocation(const cv::Rect &box, cv::Rect &nose) ;

private:

    cv::CascadeClassifier cls_ ;
    Parameters params_ ;
} ;


// A detector of eyes using the cascade classifier on the results of a face detection

class EyeDetector
{
public:

    struct Parameters {
        Parameters(): eq_hist(true) {}
        bool eq_hist ;
    } ;

    EyeDetector(): params_() {}
    EyeDetector(const Parameters &params): params_(params) {}

    // Call to load the cascade to memory. cascade_path may be a full path to the cascade file or a filename.
    // In the latter case the function will try to find the path based on the opencv installation directory and
    // operating system.

    bool init(const boost::filesystem::path &left_eye_cascade_path, const boost::filesystem::path &right_eye_cascade_path) ;

    // detect eyes inside the face box
    bool detect(const cv::Mat &im, const cv::Rect &face_box, cv::Rect &left_eye, cv::Rect &right_eye) ;

    // draw detected eyes
    void draw(cv::Mat &im, const cv::Rect &left_eye, const cv::Rect &right_eye, const cv::Vec3i &clr = cv::Vec3i(255, 0, 255)) ;

private:

    cv::CascadeClassifier leye_cls_, reye_cls_ ;
    Parameters params_ ;
} ;

class NoseDetector
{
public:

    struct Parameters {
        Parameters(): eq_hist(true) {}
        bool eq_hist ;
    } ;

    NoseDetector(): params_() {}
    NoseDetector(const Parameters &params): params_(params) {}

    // Call to load the cascade to memory. cascade_path may be a full path to the cascade file or a filename.
    // In the latter case the function will try to find the path based on the opencv installation directory and
    // operating system.

    bool init(const boost::filesystem::path &nose_cascade_path) ;

    // detect nose inside the face box
    bool detect(const cv::Mat &im, const cv::Rect &face_box, cv::Rect &nose) ;

    // draw detected nosetip
    void draw(cv::Mat &im, const cv::Rect &nose, const cv::Vec3i &clr = cv::Vec3i(255, 0, 255)) ;

private:

    cv::CascadeClassifier nose_cls_ ;
    Parameters params_ ;
} ;

}
}

#endif
