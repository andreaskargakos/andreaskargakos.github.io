#ifndef __CERTH_FACE_LGBP_H__
#define __CERTH_FACE_LGBP_H__

#include <Eigen/Core>
#include <opencv2/opencv.hpp>

#include <certh_core/PointList2D.h>

namespace certh_face {

// Local Gabor binary pattern histograms over an image
//
// Wenchao Zhang; Shiguang Shan; Wen Gao; Xilin Chen; Hongming Zhang,
// "Local Gabor binary pattern histogram sequence (LGBPHS): a novel non-statistical model for face representation and recognition,"
// ICCV 2005

class LGBPHS {
public:
    struct Parameters {
        uint gaborChannels ;
        uint gaborAngles ;

        Parameters(): gaborChannels(3), gaborAngles(6) {}
    };

    LGBPHS() {}
    LGBPHS(const Parameters &params) {}

    uint dim() const { return params_.gaborChannels * params_.gaborAngles * 58 ; }

    // compute LGBP histogram over image tiles i.e. filters the image with the Gabor filterbank and then for each tile we compute LBP
    // histogram on all the Gabor channels
    Eigen::VectorXf compute(const cv::Mat &im, const std::vector<cv::Rect> &tiles) ;

private:
    Parameters params_ ;
} ;



class LGBPHSDescriptorExtractor {
public:

    struct Parameters {
       LGBPHS::Parameters lgbp_ ;

       Parameters() {}
    };

    enum Type { Full, Upper, Lower } ;

    LGBPHSDescriptorExtractor() {}
    LGBPHSDescriptorExtractor(const Parameters &params): params_(params) {}

    Eigen::VectorXf computeOnGrid(const cv::Mat &im, const Type &type, const cv::Size &tileSize) ;
    Eigen::VectorXf computeOnLandmarks(const cv::Mat &im, const certh_core::PointList2d &pts, const Type &type, const cv::Size &tileSize) ;

private:

    Parameters params_ ;

};
}

#endif
