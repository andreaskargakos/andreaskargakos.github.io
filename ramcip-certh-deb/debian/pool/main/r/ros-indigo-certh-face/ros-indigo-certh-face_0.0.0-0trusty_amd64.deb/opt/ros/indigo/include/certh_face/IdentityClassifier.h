#ifndef __FACE_IDENTITY_CLASSIFIER_H__
#define __FACE_IDENTITY_CLASSIFIER_H__

#include <boost/filesystem.hpp>
#include <boost/smart_ptr.hpp>
#include <boost/bimap.hpp>
#include <Eigen/Core>
#include <map>
#include <certh_core/BinaryStream.h>
#include <flann/flann.hpp>

typedef flann::Index<flann::L2<float> > IndexType ;

namespace certh_face {

class IdentityClassifier {
public:

    struct Parameters {
        uint K ; // k-neigbors

        Parameters(): K(4) {}
    };


    struct FaceData {
        FaceData() {}
        FaceData(const std::string label, const Eigen::VectorXf &d):
            id_(label), descriptor_(d) {}

        std::string id_;
        Eigen::VectorXf descriptor_ ;
    };

    IdentityClassifier() {}
    IdentityClassifier(const Parameters &params): params_(params) {}

    // load training data from file
    bool init(const boost::filesystem::path &p) ;

    // train the classifier
    void train(const std::vector<FaceData> &data_) ;

    // classify sample to one of trained classed; returns label string and associated score (distance to the closest sample)
    std::string classify(const Eigen::VectorXf &descr, float &score) ;

    // save training data to disk
    void save(const boost::filesystem::path &p) ;

private:

    Parameters params_ ;

    uint nrows_, ncols_ ;
    boost::shared_ptr<IndexType> index_ ;
    boost::shared_array<float> data_ ;
    std::vector<std::string> labels_ ;
};

}
#endif
