#ifndef __FACE_ANNOTATED_DATASET_H__
#define __FACE_ANNOTATED_DATASET_H__

#include <certh_core/PointList2D.h>

#include <boost/filesystem.hpp>
#include <opencv2/opencv.hpp>

using certh_core::PointList2d ;

namespace certh_face {

// abstract container of annotated face images

class  AnnotatedDataset {
public:

    struct Annotation
    {
        std::string path_ ;              // absolute image url
        PointList2d points_ ;            // list of landmark points for this image
        cv::Rect box_ ;                  // bounding box of face within the image
        int pose_ ;                      // pose annotation
    };

    // this should be overriden to load annotations from disk

    virtual bool load( const boost::filesystem::path &root_ ) = 0 ;

    virtual unsigned int numLandmarks() const  = 0 ;

    const Annotation &getSample(unsigned int idx) const {
        return annotations_[idx] ;
    }

    unsigned int numSamples() const { return annotations_.size() ; }

    // should return the indexes of two control points that may be used to align all models (e.g. center of the eye)
    virtual void getControlPts(unsigned int &pidx1, unsigned int &pidx2) const = 0 ;

protected:

    std::vector<Annotation> annotations_ ;
};


// See http://www.dantone.me/datasets/facial-features-lfw/

class LFWDatasetETHZAnnotation: public AnnotatedDataset
{
public:

    // Annotations are in a single text file. The relative path to the annotations file and LFW images folder may be provided
    LFWDatasetETHZAnnotation(const std::string &lfw_path = "lfw/", const std::string &ann_file = "lfw_ffd_ann.txt", bool loadOnlyFrontal = true ) ;

    bool load( const boost::filesystem::path &root ) ;

    unsigned int numLandmarks() const { return 10 ; }

private:

    std::string lfw_path_ ;
    std::string lfw_ann_file_path_ ;
    bool only_frontal_ ;
};


// See http://www.dantone.me/datasets/facial-features-lfw/

class  BIOIDAnnotation: public AnnotatedDataset
{
public:

    // Annotations are in seperate files per image. The relative path to the annotations files folder and images folder  may be provided.
    //
    // The markup scheme is as follows:
    // 0 = right eye pupil
    // 1 = left eye pupil
    // 2 = right mouth corner
    // 3 = left mouth corner
    // 4 = outer end of right eye brow
    // 5 = inner end of right eye brow
    // 6 = inner end of left eye brow
    // 7 = outer end of left eye brow
    // 8 = right temple
    // 9 = outer corner of right eye
    // 10 = inner corner of right eye
    // 11 = inner corner of left eye
    // 12 = outer corner of left eye
    // 13 = left temple
    // 14 = tip of nose
    // 15 = right nostril
    // 16 = left nostril
    // 17 = centre point on outer edge of upper lip
    // 18 = centre point on outer edge of lower lip
    // 19 = tip of chin

    BIOIDAnnotation(const std::string &bioid_images = "bioid/images/", const std::string &bioid_markup = "bioid/markup/") ;

    bool load( const boost::filesystem::path &root ) ;

    unsigned int numLandmarks() const { return 20 ; }

    void getControlPts(unsigned int &pidx1, unsigned int &pidx2) const;

private:

    std::string images_ ;
    std::string markup_ ;
};


// Annotated Facial Landmarks in the Wild dataset from http://lrs.icg.tugraz.at/research/aflw/
// Not all images have annotated points so we only keep images with a subset of points as indicated below.

class AFLWDataset: public AnnotatedDataset
{
    /*

    1 Left Brow Left Corner
    2 Left Brow Right Corner
    3 Right Brow Left Corner
    4 Right Brow Right Corner
    5 Left Eye Left Corner
    6 Left Eye Center
    7 Left Eye Right Corner
    8 Right Eye Left Corner
    9 Right Eye Center
    10 Right Eye Right Corner
    11 Nose Left
    12 Nose Center
    13 Nose Right
    14 Mouth Left Corner
    15 Mouth Center
    16 Mouth Right Corner
    17 Chin Center
    */
public:

    // Annotations are in a sqlite3 database. The relative path to the database file and images folder may be provided
    AFLWDataset(const std::string &dbpath = "aflw/data/aflw.sqlite", const std::string &imgpath = "aflw/data/") ;

    bool load( const boost::filesystem::path &root ) ;

    unsigned int numLandmarks() const { return 17; }

    void getControlPts(unsigned int &pidx1, unsigned int &pidx2) const;

private:

    std::string img_path_ ;
    std::string db_path_ ;

};

}

#endif
