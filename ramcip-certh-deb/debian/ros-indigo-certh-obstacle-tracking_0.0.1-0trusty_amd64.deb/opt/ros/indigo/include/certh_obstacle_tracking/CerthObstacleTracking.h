#ifndef CERTH_OBSTACLE_TRACKING_CERTHOBSTACLETRACKING_H
#define CERTH_OBSTACLE_TRACKING_CERTHOBSTACLETRACKING_H

#include <opencv2/opencv.hpp>
#include <cv_bridge/cv_bridge.h>

#include <boost/filesystem.hpp>
#include <boost/regex.hpp>
#include <boost/lexical_cast.hpp>
#include <boost/format.hpp>
#include <boost/chrono/thread_clock.hpp>


#include <certh_core/Helpers.h>
#include <certh_core/RGBDUtil.h>
#include <certh_core/Calibration.h>

#include <pcl_conversions/pcl_conversions.h>
#include <pcl/point_cloud.h>
#include <pcl/visualization/pcl_visualizer.h>
#include <pcl/sample_consensus/method_types.h>
#include <pcl/sample_consensus/model_types.h>
#include <pcl/segmentation/sac_segmentation.h>
#include <pcl/segmentation/extract_clusters.h>
#include <pcl/filters/extract_indices.h>
#include <pcl/filters/project_inliers.h>
#include <pcl/filters/voxel_grid.h>
#include <pcl/search/kdtree.h>
#include <pcl/features/normal_3d_omp.h>
#include <pcl/surface/poisson.h>
#include <pcl/registration/icp.h>
#include <pcl/surface/concave_hull.h>
#include <pcl/filters/passthrough.h>
#include <pcl/io/pcd_io.h>
#include <pcl/filters/crop_hull.h>
#include <pcl/features/integral_image_normal.h>
#include <pcl/segmentation/organized_multi_plane_segmentation.h>
#include <pcl/segmentation/euclidean_cluster_comparator.h>
#include <pcl/segmentation/organized_connected_component_segmentation.h>

#define WINDOW_SIZE 10

class CerthObstacleTracking{

public:

  CerthObstacleTracking(double z_min, double z_max,
                        double y_min, double y_max,
                        double x_min, double x_max,
                        double min_dist, double max_dist,
                        double cluster_min_dist, double cluster_max_dist)
      : z_min_(z_min), z_max_(z_max), y_min_(y_min), y_max_(y_max), x_min_(x_min), x_max_(x_max),
        min_dist_(min_dist), max_dist_(max_dist),
        cluster_min_dist_(cluster_min_dist), cluster_max_dist_(cluster_max_dist),
        cluster_id_(0), window_size_(WINDOW_SIZE)
  {}

    CerthObstacleTracking();
    ~CerthObstacleTracking();
    CerthObstacleTracking(double z_min, double z_max,
                          double y_min, double y_max,
                          double x_min, double x_max);
    struct Sphere{
        pcl::PointXYZ center;
        double radius;
    };

    struct Cylinder{
        pcl::PointXYZ center;
        Eigen::Vector3f normal_axis;
        double radius;
    };

    struct Cluster{
        pcl::PointCloud<pcl::PointXYZRGB>::Ptr cloud_;
        cv::Mat mask_;
        Eigen::Vector4d centroid_;
        int size_;
        std::string label_;
        double min_plane_distance_;
        double max_plane_distance_;
        double x_length_;
        double y_length_;
        double z_length_;
    };

    void projectPointToPlane(const pcl::PointXYZRGB &initial_p,
                                                     const Eigen::Vector4d &coeffs,
                                                     pcl::PointXYZRGB &projected_p);

    void segmentWorkspace(const pcl::PointCloud<pcl::PointXYZRGB>::Ptr &cloud,
                            pcl::PointCloud<pcl::PointXYZRGB>::Ptr &workspace,
                            std::vector<std::pair<int, int> > &image_indices,
                            cv::Mat &mask);

    void segmentWorkspace(const pcl::PointCloud<pcl::PointXYZRGB>::Ptr &cloud,
                                                       pcl::PointCloud<pcl::PointXYZRGB>::Ptr &workspace,
                                                       std::vector<std::pair<int, int> > &image_indices,
                                                       cv::Mat &mask,
                                                       Eigen::Affine3d &tf);

    void clusterWorkspace(const pcl::PointCloud<pcl::PointXYZRGB>::Ptr &cloud,
                          const std::vector<std::pair<int, int> > &image_indices,
                                std::vector<Cluster> &clusters, int width, int height);

    void clusterWorkspace(const pcl::PointCloud<pcl::PointXYZRGB>::Ptr &cloud,
                                std::vector<Cluster> &clusters,
                                double cx, double cy, double fx, double fy);

    void clusterFloorWorkspace(const pcl::PointCloud<pcl::PointXYZRGB>::Ptr &cloud,
                                std::vector<Cluster> &clusters,
                                double cx, double cy, double fx, double fy, int cl_size);

    void createSphereRepresentation(pcl::PointCloud<pcl::PointXYZRGB>::Ptr &obstacle,
                                    Eigen::Matrix4f pose,
                                    std::pair<std::vector<pcl::PointXYZ>, float> &spheres);

    void captureImages();

    void calibrate();

    void draw();

    void setParameters(float x_min, float x_max, float y_min, float y_max, float z_min, float z_max, float min_dist, float max_dist,
                       float cluster_min_dist, float cluster_max_dist,
                       const Eigen::Vector4f &coeffs, const pcl::PointXYZRGB &point_plane,
                       const pcl::PointCloud<pcl::PointXYZRGB>::Ptr &convex_hull,
                       const pcl::PointCloud<pcl::PointXYZRGB>::Ptr &supporting_surface_cloud,
                       const std::vector<pcl::Vertices> &polygons);



    /* monitoring */
    void clusterWorkspace(const pcl::PointCloud<pcl::PointXYZRGB>::Ptr &cloud,
                          const std::vector<std::pair<int, int> > &image_indices,
                                std::vector<Cluster> &clusters);

    void segmentSupportingSurface(pcl::PointCloud<pcl::PointXYZRGB>::Ptr &cloud);

    void segmentSupportingSurface(pcl::PointCloud<pcl::PointXYZRGB>::Ptr &cloud, bool floor);

    void segmentSupportingSurface(pcl::PointCloud<pcl::PointXYZRGB>::Ptr &cloud, bool floor, Eigen::Affine3d &tf);

    void keepLargestCluster(const cv::Mat &depth, const certh_core::PinholeCamera &cam, cv::Mat &final_mask);

    void setKeyFrame(std::vector<Cluster> &clusters);

    void checkClusterCorrespondences2(const std::vector<Cluster> &clusters,
                                           int &num_of_new_clusters,
                                           std::vector<Cluster> &new_key_clusters,
                                           bool &change_in_clusters,
                                     const cv::Mat &rgb, const cv::Mat &depth, const certh_core::PinholeCamera &cam,
                                      std::vector<std::string>& removed_objects);


    Eigen::Vector4f coeffs_;
    Cluster last_cluster_removed_;
    Eigen::Vector4f pcaCentroid_;

private:

    bool out_of_window(std::pair<int, int> cl);
    bool is_cluster_stable(std::vector<std::pair<int, int> > group);
    inline bool world_to_image_coords(float x, float y, float z, int &row, int &col, double cx, double cy, double fx, double fy){
        row = int(y * fy / z + cy);
        col = int(x * fx / z + cx);
    }

    cv::Mat mask_;
    pcl::PointXYZRGB point_plane_;
    pcl::PointCloud<pcl::PointXYZRGB>::Ptr convex_hull_;
    pcl::PointCloud<pcl::PointXYZRGB>::Ptr supporting_surface_cloud_;
    std::vector<pcl::Vertices> polygons_;
    std::vector<Sphere> obstacles_;

    Eigen::Matrix4f projection_matrix_;
    Eigen::Matrix4f back_projection_matrix_;

    pcl::PointXYZRGB minPoint_;
    pcl::PointXYZRGB maxPoint_;

    float z_min_;
    float z_max_;
    float y_min_;
    float y_max_;
    float x_min_;
    float x_max_;

    float min_dist_;
    float max_dist_;

    float cluster_min_dist_;
    float cluster_max_dist_;

    Eigen::Vector4f object_bounding_box_;
    Eigen::Matrix4f object_pose_;
    std::string object_label_;

    double height_;
    double y_supporting_surface_;

    long int cluster_id_;

    std::vector<Cluster> key_frame_;
    std::deque<std::vector<Cluster> > frame_window_;
    std::vector<int> counter_;
    std::vector<std::vector<std::pair<int, int> > > cluster_groupings_;
    int window_size_;

    Eigen::Matrix4f trans_pose_inv_;
};

#endif
