#pragma once
#include <opencv/cxcore.h>
#include <map>

enum joints
{
	invalid_joint = -1,
	joint_head = 0,
	joint_left_elbow = 1,
	joint_left_foot = 2,
	joint_left_hand = 3,
	joint_left_hip = 4,
	joint_left_knee = 5,
	joint_left_shoulder = 6,
	joint_neck = 7,
	joint_right_elbow = 8,
	joint_right_foot = 9,
	joint_right_hand = 10,
	joint_right_hip = 11,
	joint_right_knee = 12,
	joint_right_shoulder = 13,
	joint_torso = 14,
	num_joints = 15,
};
//////////////////////////////////////////////////////////////////////////
enum joints_msr
{
	msr_invalid_joint = -1,
	msr_joint_right_shoulder = 0,
	msr_joint_left_shoulder = 1,
	msr_joint_neck = 2,
	msr_joint_torso = 3,
	msr_joint_right_hip = 4,
	msr_joint_left_hip = 5,
	msr_joint_hip = 6,
	msr_joint_right_elbow = 7,
	msr_joint_left_elbow = 8,
	msr_joint_right_wrist = 9,
	msr_joint_left_wrist = 10,
	msr_joint_right_hand = 11,
	msr_joint_left_hand = 12,
	msr_joint_right_knee = 13,
	msr_joint_left_knee = 14,
	msr_joint_right_ankle = 15,
	msr_joint_left_ankle = 16,
	msr_joint_right_foot = 17,
	msr_joint_left_foot = 18,
	msr_joint_head = 19,
	msr_num_joints = 20
};
//////////////////////////////////////////////////////////////////////////
typedef std::map<int, cv::Point3d> skeleton;
//////////////////////////////////////////////////////////////////////////
struct detectionResult
{
	int gt;
	int detection;
	float score;
	detectionResult()
	{
		gt = -1;
		detection = -1;
		score = 0.0;
	}
	detectionResult(int g, int d, float s)
	{
		gt = g;
		detection = d;
		score = s;
	}
};
//////////////////////////////////////////////////////////////////////////
