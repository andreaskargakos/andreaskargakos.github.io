#pragma once
#include <vector>
//#include <Eigen/Core>
#include <eigen3/Eigen/Core>
#include <map>
//#include <core.hpp>

#include <certh_action_recognition/eigenJoints.h>
#include <certh_action_recognition/NaiveBayesNN.h>

//////////////////////////////////////////////////////////////////////////
struct skeleton_struct
{
	std::map<joints, cv::Point3d> s_joints;
	double confidence;
	int id;
	long unsigned int timestamp;
	skeleton_struct()
	{
		confidence = 0.0;
		id = -1;
		timestamp = -1;
	}
};
//////////////////////////////////////////////////////////////////////////
struct action_skeleton_input 
{
	long unsigned int timestamp_;
	std::vector<std::string> joint_names_;
	std::vector<Eigen::Vector3d> joint_positions_;
};
//////////////////////////////////////////////////////////////////////////
struct action_object_input 
{
	long unsigned int timestamp_;
	int ID_;
};
//////////////////////////////////////////////////////////////////////////
struct action_output 
{
  long unsigned int timestamp_;
	int ID_;
};
//////////////////////////////////////////////////////////////////////////
typedef std::map<int, cv::Point3d> skeleton;
//////////////////////////////////////////////////////////////////////////
class certh_action_recognition
{
public:
	certh_action_recognition();
  void set_params(bool debuging_mode_in, float hand2mouth_distance_thress_in, float object_interaction_distance_thress_in,
              float movement_threshold_in, float height_drop_threshold_in, int action_threshold_in, int object_delay_threshold_in,
                           int action_delay_in, int open_cupboard_delay_in, float hands_threshold_in, int cup_id_in, int pillbox_id_in, int cupboard_id_in
                           ,std::string model_directory_in);
	~certh_action_recognition();
	bool addObjectFrame(action_object_input new_object);
	bool addSkeletonFrame(action_skeleton_input new_skeleton);
	action_output getLattestAction() { return m_lattest_action; };

private:
	bool initialize();
	skeleton_struct convertSkeletonInput2Struct(action_skeleton_input new_skeleton);
	joints convert_str_to_joint(std::string str);
	bool processLattestFrame();
	bool action_detection(std::vector<int> &action_buffer, int frame);
	bool action_detection_eig(std::vector<int> &action_buffer, int frame);
	int action_detection_eigenJoints();
	int mapEigenJointsActions2Ramcip(int act_id);
	int getClosestFrameIdx(long unsigned int ts);

	action_object_input m_last_object_used;
	int last_object_frame_no;
	std::vector<skeleton_struct> m_skeletons_buffer;
	NaiveBayesNN m_NBNN;
	action_output m_lattest_action;
  QString m_str_model_directory;

	bool b_debuging_mode;
	double hand2mouth_distance_thress;
	double object_interaction_distance_thress;
	double movement_threshold;
	double height_drop_threshold;
	int action_threshold;
	int object_delay_threshold;
	int action_delay;
	int open_cupboard_delay;
	double hands_threshold;
	int i_cup_id;
	int i_pillbox_id;
	int i_cupboard_id;
	bool started_eating;
	int last_drinking;
	int i_frame;
	int max_frame_buffer_size;

	bool posture_seated;
	bool cupboard_open;
	std::vector<int> walking_buffer;
	std::vector<int> hand2mouth_buffer;
	std::vector<int> stand2sit_buffer;
	std::vector<int> sit2stand_buffer;
	std::vector<int> eigen_buffer;
	std::vector<int> hands_buffer;
	std::vector<int> last_hand_to_mouth;
	std::vector<int> possible_open_cupboard;
	std::map<int, long unsigned int> m_frames_index;

};

