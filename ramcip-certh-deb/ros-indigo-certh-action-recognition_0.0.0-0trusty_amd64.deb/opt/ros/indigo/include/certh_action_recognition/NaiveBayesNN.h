#pragma once
#include "eigenJoints.h"

class NaiveBayesNN
{
public:
	NaiveBayesNN();
	~NaiveBayesNN();

  bool setTrainData(std::map<int, std::vector<eigenJoints> > data);
	bool setTrainData(QString str_filelist);
	bool train();
	void setOutputDirectory(QString d) { m_str_output_directory = d; };
	bool loadModel(QString model_file);
	void test(QString input_file_list);
	std::pair<int, double> test(cv::Mat feature);

private:
	cv::Mat ApplyPCAtoMat(int maxComponents = 128);
	bool serializeDataToXML(cv::Mat data);
	bool serializeLabelsToXML(cv::Mat labels);
	bool serializeEigenVectorsToXML(cv::Mat eigenVectors);
	std::map<int, std::pair<int, int> > buildIndexes(cv::Mat dataReduced);
	bool serializeClassStartEndMap(std::map<int, std::pair<int, int> > ClassStartEndMap);
	bool exportMeanLenghts();
	std::pair<int, double> KnnSearch_V2(cv::Mat query);



  std::map<int, std::pair<int, int> > m_class_startend_map;
	cv::Mat m_reducedData;
	QString m_str_basename;
	QString m_str_model_path;
  std::map<int, std::vector<int> > m_lenghts;
	QString m_str_output_directory;
  std::map<int, std::vector<eigenJoints> > m_Data;
	cv::Mat m_train_data;
	cv::Mat m_labels;
	cv::Mat m_reducedEigenVectors;
};

