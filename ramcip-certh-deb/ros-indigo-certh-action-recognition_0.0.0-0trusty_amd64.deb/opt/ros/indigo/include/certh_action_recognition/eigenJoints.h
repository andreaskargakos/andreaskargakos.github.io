#pragma once
#include <certh_action_recognition/definitions.h>

#include <QString>
#include <QDir>


class eigenJoints
{
public:
	eigenJoints();
	eigenJoints(QString str_input_directory);
	~eigenJoints();

	bool setSkeletonData(std::map<int, skeleton> data);
	int getSequenceLength() { return (int)m_sequence.size(); };
	cv::Mat getFeature() { return m_eigenJoints; };
	bool setInputDirectory(QString dir);
	int getActionID() { return i_action_id; };
	void setOutputDirectory(QString d) { m_str_output_directory = d; };
	bool saveFeatures();
	QString getName() { return m_name; };

private:
	bool loadDirectory(QDir inp_dir);
	joints convert_str_to_joint(QString str);
	joints_msr convert_str_to_joint_msr(QString str);
	bool CalcParamsSeq(bool normalizeFlag = false, bool use_next_frame = false);
	cv::Mat calculateFcc();
	cv::Mat calculateFcp();
	cv::Mat calculateFci();
	cv::Mat calculateFcn();
	cv::Mat calculateFcp2();
	cv::Mat calculateFci2();
	cv::Mat calculateFcn2();
	bool saveFeatures(cv::Mat feature);

	bool b_normalize_features;
	bool b_next_frame_variation;
	std::map<int, skeleton> m_sequence;
	cv::Mat m_Fcc;
	cv::Mat m_Fcp;
	cv::Mat m_Fci;
	cv::Mat m_Fcn;
	cv::Mat m_eigenJoints;
	QString m_name;
	QString m_str_output_directory;
	std::map<joints, float> m_joint_travelled_distance;
	cv::Mat m_joint_travelled_distance_comp;

	QString m_str_input_directory;
	int i_action_id;
	int i_subject_id;
	int i_repetition;
	bool b_certh_data;
	bool b_add_travelled_distance;
	bool b_use_only_corresponding_joints;
	int i_num_joints;
};

