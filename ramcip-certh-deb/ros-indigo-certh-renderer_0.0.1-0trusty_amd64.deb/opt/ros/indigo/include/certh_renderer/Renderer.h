#ifndef __CERTH_RENDERER_H__
#define __CERTH_RENDERER_H__

#include <certh_core/Calibration.h>
#include <certh_core/SkinnedMesh.h>

#include <boost/shared_ptr.hpp>
#include <boost/filesystem.hpp>

#include <eigen3/Eigen/Geometry>

#include <GL/glew.h>

#include <assimp/scene.h>
#include <assimp/postprocess.h>
#include <assimp/cimport.h>

class OffscreenRenderingEngine ;

namespace certh_renderer {

class Renderer {
public:

    enum RenderMode { RenderFlat, // no lighting, makes a mask of each object using its diffuse material color
                      RenderSmooth, // lighting enabled/smooth/no texture
                      RenderTextured // texture mapping/no shading
                    } ;

    // create an off-screen OpenGL renderer object
    // The renderer uses a vertex/frgament shader

    Renderer(const certh_core::PinholeCamera &cam, RenderMode mode = RenderFlat) ;

    // helpers for single object rendering

    Renderer(const aiScene *scene, // the mesh to render
                      const boost::filesystem::path &model_path,
                      const certh_core::PinholeCamera &cam,
                      RenderMode mode = RenderFlat) ;

    Renderer(const std::string &model_path,
                      const certh_core::PinholeCamera &cam,
                      RenderMode mode = RenderFlat) ;

    Renderer(const certh_core::SkinnedMesh &mesh,
                    const certh_core::PinholeCamera &cam,
                    const cv::Mat &texture = cv::Mat(),
                    RenderMode mode = RenderFlat) ;

    // add an assimp mesh, model_path is used to find textures relative to this, returns the object id
    int addObject(const aiScene *scene, const boost::filesystem::path &model_path) ;

    // add a skinned mesh with optional texture, returns the object id
    int addObject(const certh_core::SkinnedMesh &smesh, const cv::Mat &texture = cv::Mat()) ;

    // add mesh object from file
    int addObject(const std::string &mesh_filename ) ;

    // set the world to camera transform of the specified object
    void setObjectTransform(int oid, const Eigen::Matrix4f &tf) ;

    // set the pose of the specified object
    void setObjectPose(int oid, const certh_core::Pose &p) ;

    // render the specified object only
    void render(int oid) ;

    // render scene
    void render() ;

    // set world matrix and pose and render (only for the first object in the list)
    void render(const Eigen::Matrix4f &tf) ;
    void render(const Eigen::Matrix4f &tf, const certh_core::Pose &p) ;

    // get color buffer (BGRA format or BGR format)
    cv::Mat getColor(bool alpha=true) ;

    // blend color buffer with background image using given alpha value
    cv::Mat getColor(cv::Mat &bg, float alpha = 0.5) ;

    // get depth buffer (normalized 16bit values in camera coordinates)
    cv::Mat getDepth() ;

    // set image background color (default is black transparent)
    void setBackgroundColor(float r, float g, float b, float a = 0.0) ;

    void setMaterial(int oid, const Eigen::Vector4f &ambient, const Eigen::Vector4f &diffuse) ;

    void setLight(const Eigen::Vector3f &dir, const Eigen::Vector4f &ambient, const Eigen::Vector4f &diffuse) ;

private:

    enum VB_TYPES {
        INDEX_BUFFER,
        POS_VB,
        NORMAL_VB,
        BONE_VB,
        TEXCOORD_VB,
        NUM_VBs
    };

    struct MeshData {
        MeshData() ;
        GLuint VAO_;
        GLuint buffers_[NUM_VBs];
        GLuint texture_id_ ;
        GLuint elem_count_ ;
        bool has_bones_ ;
        Eigen::Vector4f diffuse_, specular_, ambient_, emission_ ;
        float shininess_ ;
        int oid_ ;
        GLuint prog_ ;
        Eigen::Matrix4f ltrans_ ;
        certh_core::Pose pose_ ;
        certh_core::Skeleton skeleton_ ;
    };

    void setup(const certh_core::PinholeCamera &cam, RenderMode mode) ;

    void initGL() ;
    //void initBuffers(const certh_core::SkinnedMesh &mesh) ;
    void initBuffers(MeshData &data, const aiMesh *mesh) ;
    void initBuffers(MeshData &data, const certh_core::SkinnedMesh &mesh) ;

    void initView(GLuint prog) ;
    void setModelTransform(const Eigen::Matrix4f &trans, GLuint prog) ;
    void setLight(GLuint prog) ;
    void setMaterial(const MeshData &data, GLuint prog) ;
    void render(const MeshData &mesh) ;

    void initShaders() ;
    void setBoneTransform(uint index, const Eigen::Matrix4f& tr) ;
    GLuint initTexture(const cv::Mat &im) ;
    bool importAssimpMesh(const std::string &file_name) ;
    bool importAssimpRecursive(const struct aiScene *sc, const boost::filesystem::path &model_path, const struct aiNode* nd, const Eigen::Matrix4f &ptf) ;
    void initAssimpMaterial(MeshData &data, const struct aiMaterial *mtl, const boost::filesystem::path &model_path) ;

    cv::Mat readBuffer() ;

    int width_, height_ ;
    certh_core::PinholeCamera cam_ ;

    RenderMode mode_ ;
    Eigen::Vector4f bg_ ;
    Eigen::Vector3f light_dir_ ;
    Eigen::Vector4f light_diffuse_, light_ambient_ ;

    boost::shared_ptr<OffscreenRenderingEngine> engine_ ;

    std::vector<MeshData> data_ ;

    typedef std::multimap<int, uint> OIDMap ;
    OIDMap idmap_ ;
    std::map<std::string, uint> textures_ ;
    int lastoid_ ;

    GLuint program_rigid_, program_skinned_, fs_, vs_skinned_, vs_rigid_;
    Eigen::Matrix4f perspective_ ;
};

}

#endif
