#ifndef __OFF_SCREEN_RENDERER_H__
#define __OFF_SCREEN_RENDERER_H__

#include <certh_core/Calibration.h>

#include <boost/shared_ptr.hpp>
#include <boost/filesystem.hpp>


#include <pcl/PolygonMesh.h>
#include <eigen3/Eigen/Geometry>

#include <assimp/cimport.h>
#include <assimp/scene.h>
#include <assimp/postprocess.h>

#include <GL/glew.h>

class OffscreenRenderingEngine ;

namespace certh_renderer {

class OffscreenRenderer {
public:

    enum RenderMode {
                      RenderWireFrame,
                      RenderFlat, // no lighting, makes a mask
                      RenderSolid, // lighting enabled/smooth/no texture
                      RenderTextured, // with texture and lighting
                      RenderFaces // Render each face with a constant color
                    } ;

    // create an off-screen renderer object
    // From blender export to obj format (specify Y forward, Z up to retain the axis ordering)
    OffscreenRenderer(const aiScene *scene, // the mesh to render
                      const boost::filesystem::path &model_path, //
                      const certh_core::PinholeCamera &cam, // the camera
                      RenderMode mode = RenderFlat, // rendering mode
                      std::map<const aiFace *, cv::Vec3b> &clrs = _no_face_map // face color, used in RenderFaces mode
                      ) ;


    // render a view using the specified world-to-camera matrix
    void render(const Eigen::Matrix4d &tf) ;

    // get color buffer (BGRA format)
    cv::Mat getColor(bool alpha=true) ;

    // get depth buffer (normalized 16bit values in camera coordinates)
    cv::Mat getDepth() ;

    // set image background color (default is black transparent)
    void setBackgroundColor(float r, float g, float b, float a = 0.0) ;


private:

    void initGL() ;
    void initView(const Eigen::Matrix4d &tf) ;

    void makeMeshDisplayList(const aiScene *scene);

    cv::Mat readBuffer() ;

    double padding_ ;

    int width_, height_ ;
    certh_core::PinholeCamera cam_ ;

    unsigned int dl_index_ ;
    RenderMode mode_ ;
    Eigen::Vector4f bg_, fg_ ;
    std::map<std::string, unsigned int> textures_ ;
    std::map<const aiFace *, cv::Vec3b> face_map_ ;

    boost::shared_ptr<OffscreenRenderingEngine> engine_ ;

    static std::map<const aiFace *, cv::Vec3b> _no_face_map ;
};

// sampling of the viewing sphere (uniformly over the surface)

void makeViewsOnSphere(const Eigen::Vector3d &c, // where the camera will look at,
                                    const Eigen::Vector3d &up, // this should point towards the correct side of the half dome,
                                    float min_radius, float max_radius, float radius_step, // distance of the camera from the object
                                    float roll_min, float roll_max, float roll_step, // roll of the camera
                                    int nPts, // number of points uniformly sampled on the sphere for each radius and roll
                                    std::vector<Eigen::Matrix4d> &views) ;


// variant to restrict z-axis coordinate between +-zone

void makeViewsOnSphere(const Eigen::Vector3d &c, float zone, float min_radius, float max_radius, float radius_step,
                       float min_roll, float max_roll, float roll_step,
                       int nPts, std::vector<Eigen::Matrix4d> &views) ;

// same as above but working on subdivision of icosahedron (maybe better than the above for sparse samplings depth=0)

void makeViewsOnGeodesicDome(const Eigen::Vector3d &c, // where the camera will look at,
                                          const Eigen::Vector3d &up, // this should point towards the correct side of the half dome,
                                          float min_radius, float max_radius, float radius_step, // distance of the camera from the object
                                          float roll_min, float roll_max, float roll_step, // roll of the camera
                                          int depth, // subdivision depth: number of pts is 240*4^depth
                                          std::vector<Eigen::Matrix4d> &views) ;

}



#endif
