#ifndef __OFF_SCREEN_RENDERER_H__
#define __OFF_SCREEN_RENDERER_H__

#include <certh_core/Calibration.h>

#include <boost/shared_ptr.hpp>
#include <boost/filesystem.hpp>

#include <Eigen/Geometry>

#include <certh_core/SkinnedMesh.h>

#include <GL/glew.h>

class OffscreenRenderingEngine ;

namespace certh_renderer {

class SkinnedMeshRenderer {
public:

    enum RenderMode {
                      RenderFlat, // no lighting, makes a mask
                      RenderSmooth, // lighting enabled/smooth/no texture
                      RenderTextured // texture mapping/no shading
                    } ;

    // create an off-screen OpenGL renderer object
    // The renderer uses a vertex/frgament shader so that vertices are loaded into the GPU only once
    // This also means than you need to run this on a PC with X server running

    SkinnedMeshRenderer(const certh_core::SkinnedMesh &mesh, // the mesh to render
                        const certh_core::PinholeCamera &cam, // the camera
                        RenderMode mode = RenderFlat) ;

    // render a view using the specified world-to-camera matrix and skeleton pose
    void render(const Eigen::Matrix4d &tf, const certh_core::Pose &p) ;

    // get color buffer (BGRA format or BGR format)
    cv::Mat getColor(bool alpha=true) ;

    // blend color buffer with background image using given alpha value
    cv::Mat getColor(cv::Mat &bg, float alpha = 0.5) ;

    // get depth buffer (normalized 16bit values in camera coordinates)
    cv::Mat getDepth() ;

    // set image background color (default is black transparent)
    void setBackgroundColor(float r, float g, float b, float a = 0.0) ;

    void setMaterialColor(float r, float g, float b, float a = 1.0) ;

    void setLight(const Eigen::Vector3f &dir, float ambient = 0.2, float diffuse = 0.8) ;

    // set texture to be used in
    void setTexture(const cv::Mat &texture) ;

private:

    void initGL() ;
    void initBuffers(const certh_core::SkinnedMesh &mesh) ;
    void initView(const Eigen::Matrix4d &tf) ;
    void initShader() ;
    void setBoneTransform(uint index, const Eigen::Matrix4f& tr) ;
    void initTexture() ;

    cv::Mat readBuffer() ;

    int width_, height_ ;
    certh_core::PinholeCamera cam_ ;

    RenderMode mode_ ;
    Eigen::Vector4f bg_, fg_ ;
    float ambient_, diffuse_ ;
    Eigen::Vector3f light_dir_ ;

    boost::shared_ptr<OffscreenRenderingEngine> engine_ ;

    enum VB_TYPES {
        INDEX_BUFFER,
        POS_VB,
        NORMAL_VB,
        BONE_VB,
        TEXCOORD_VB,
        NUM_VBs
    };

    GLuint VAO_;
    GLuint buffers_[NUM_VBs];
    const certh_core::SkinnedMesh &mesh_ ;
    GLuint shader_, vs_shader_obj_, fs_shader_obj_ ;
    Eigen::Matrix4f perspective_ ;
    cv::Mat texture_ ;
    GLuint texture_id_ ;
    std::vector<Eigen::Vector3f> gl_pos_, gl_norm_ ;
    std::vector<Eigen::Vector3f> gl_tex_coord_ ;
    std::vector<certh_core::SkinnedMesh::VertexBoneData> gl_bones_ ;
};

}
#endif
